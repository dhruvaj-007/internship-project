import Image from 'next/image'
import { Reveal } from '@/components/reveal'

export const metadata = {
  title: 'About — Chronos Elite',
  description:
    'The story behind Chronos Elite: master watchmaking, modern technology, and a relentless pursuit of precision.',
}

const stats = [
  { value: '40+', label: 'Years of watchmaking' },
  { value: '120k', label: 'Collectors worldwide' },
  { value: '2yr', label: 'Warranty on every piece' },
  { value: '100%', label: 'Authenticity guaranteed' },
]

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
      <Reveal className="mx-auto max-w-3xl text-center">
        <p className="text-sm tracking-widest text-accent uppercase">
          Our Story
        </p>
        <h1 className="mt-3 font-heading text-4xl text-balance sm:text-5xl">
          Precision is a promise we keep
        </h1>
        <p className="mt-5 text-pretty text-lg leading-relaxed text-muted-foreground">
          Chronos Elite was founded on a simple belief: a watch should be as
          enduring as the moments it measures. We blend centuries-old
          watchmaking craft with modern engineering to create timepieces worth
          passing down.
        </p>
      </Reveal>

      <Reveal className="mt-12">
        <div className="relative aspect-[21/9] overflow-hidden rounded-2xl border border-border">
          <Image
            src="/watches/hero.png"
            alt="Chronos Elite craftsmanship"
            fill
            sizes="100vw"
            className="object-cover"
          />
        </div>
      </Reveal>

      <div className="mt-16 grid grid-cols-2 gap-6 lg:grid-cols-4">
        {stats.map((stat, i) => (
          <Reveal key={stat.label} delay={i * 100}>
            <div className="rounded-2xl border border-border bg-card p-8 text-center">
              <p className="font-heading text-4xl text-primary">{stat.value}</p>
              <p className="mt-2 text-sm text-muted-foreground">{stat.label}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </div>
  )
}
