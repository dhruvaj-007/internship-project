import Link from 'next/link'
import { notFound } from 'next/navigation'
import { Check, ChevronRight, Star } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ProductGallery } from '@/components/product/product-gallery'
import { AddToCartButton } from '@/components/product/add-to-cart-button'
import { ReviewsSection } from '@/components/product/reviews-section'
import { ProductCard } from '@/components/product-card'
import {
  formatPrice,
  getProduct,
  getRelated,
  products,
} from '@/lib/products'

export function generateStaticParams() {
  return products.map((p) => ({ slug: p.slug }))
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>
}) {
  const { slug } = await params
  const product = getProduct(slug)
  if (!product) return {}
  return {
    title: `${product.name} — Chronos Elite`,
    description: product.description,
  }
}

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>
}) {
  const { slug } = await params
  const product = getProduct(slug)
  if (!product) notFound()

  const related = getRelated(product.slug, product.category)

  const specs = [
    { label: 'Case Size', value: product.caseSize },
    { label: 'Water Resistance', value: product.waterResistance },
    { label: 'Movement', value: product.movement },
    { label: 'Glass', value: product.glass },
    { label: 'Case Material', value: product.caseMaterial },
    { label: 'Strap', value: product.strapMaterial },
  ]

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <nav
        aria-label="Breadcrumb"
        className="mb-8 flex items-center gap-1.5 text-sm text-muted-foreground"
      >
        <Link href="/" className="transition-colors hover:text-foreground">
          Home
        </Link>
        <ChevronRight className="size-4" />
        <Link
          href={`/collections/${product.category.toLowerCase()}`}
          className="transition-colors hover:text-foreground"
        >
          {product.category}
        </Link>
        <ChevronRight className="size-4" />
        <span className="text-foreground">{product.name}</span>
      </nav>

      <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
        <ProductGallery image={product.image} name={product.name} />

        <div className="lg:py-4">
          <p className="text-sm tracking-widest text-accent uppercase">
            {product.brand}
          </p>
          <h1 className="mt-2 font-heading text-4xl text-balance">
            {product.name}
          </h1>

          <div className="mt-4 flex items-center gap-2">
            <div className="flex items-center gap-0.5 text-accent">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={`size-4 ${
                    i < Math.round(product.rating)
                      ? 'fill-current'
                      : 'text-muted-foreground'
                  }`}
                />
              ))}
            </div>
            <span className="text-sm text-muted-foreground">
              {product.rating.toFixed(1)} ({product.reviewCount} reviews)
            </span>
          </div>

          <p className="mt-6 font-heading text-3xl tabular-nums">
            {formatPrice(product.price)}
          </p>

          <p className="mt-6 text-pretty leading-relaxed text-muted-foreground">
            {product.description}
          </p>

          <ul className="mt-6 flex flex-col gap-2.5">
            {product.highlights.map((highlight) => (
              <li key={highlight} className="flex items-center gap-2.5 text-sm">
                <Check className="size-4 shrink-0 text-primary" />
                {highlight}
              </li>
            ))}
          </ul>

          <div className="mt-8 flex gap-3">
            <AddToCartButton product={product} />
            <Button variant="outline" size="lg" className="h-12">
              Save
            </Button>
          </div>

          <div className="mt-10">
            <h2 className="mb-4 font-heading text-lg">Specifications</h2>
            <dl className="grid grid-cols-2 gap-x-6 overflow-hidden rounded-xl border border-border">
              {specs.map((spec, i) => (
                <div
                  key={spec.label}
                  className={`flex justify-between gap-3 border-border px-4 py-3 text-sm ${
                    i < specs.length - 2 ? 'border-b' : ''
                  } ${i % 2 === 0 ? 'border-r' : ''}`}
                >
                  <dt className="text-muted-foreground">{spec.label}</dt>
                  <dd className="text-right font-medium">{spec.value}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </div>

      <ReviewsSection
        rating={product.rating}
        reviewCount={product.reviewCount}
      />

      {related.length > 0 && (
        <section className="mt-16">
          <h2 className="mb-8 font-heading text-2xl">You may also like</h2>
          <div className="grid grid-cols-2 gap-5 lg:grid-cols-4">
            {related.map((p) => (
              <ProductCard key={p.slug} product={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  )
}
