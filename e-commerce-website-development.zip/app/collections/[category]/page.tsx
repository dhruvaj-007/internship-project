import { notFound } from 'next/navigation'
import { CollectionView } from '@/components/collection-view'
import { products, type Category } from '@/lib/products'

const meta: Record<string, { title: string; description: string; filter?: Category }> = {
  men: {
    title: "Men's Watches",
    description:
      'Bold, precise, and built to last. Explore divers, chronographs and GMT complications engineered for the modern man.',
    filter: 'Men',
  },
  women: {
    title: "Women's Watches",
    description:
      'Elegant proportions and refined finishing. Discover dress watches and smart companions designed to be treasured.',
    filter: 'Women',
  },
  smart: {
    title: 'Smart Watches',
    description:
      'Cutting-edge sensors meet timeless design. Stay connected without compromising on craftsmanship.',
    filter: 'Smart',
  },
  luxury: {
    title: 'Luxury Watches',
    description:
      'Our most exclusive timepieces, from hand-finished tourbillons to open-worked skeletons for the serious collector.',
    filter: 'Luxury',
  },
  all: {
    title: 'All Timepieces',
    description:
      'The complete Chronos Elite collection across every style, movement and material.',
  },
}

export function generateStaticParams() {
  return Object.keys(meta).map((category) => ({ category }))
}

export default async function CollectionPage({
  params,
}: {
  params: Promise<{ category: string }>
}) {
  const { category } = await params
  const config = meta[category]
  if (!config) notFound()

  const filtered = config.filter
    ? products.filter((p) => p.category === config.filter)
    : products

  return (
    <CollectionView
      title={config.title}
      description={config.description}
      products={filtered}
    />
  )
}
