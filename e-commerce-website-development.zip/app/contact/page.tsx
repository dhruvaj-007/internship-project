'use client'

import { useState } from 'react'
import { Mail, MapPin, Phone } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Reveal } from '@/components/reveal'

const details = [
  { icon: Mail, label: 'Email', value: 'concierge@chronoselite.com' },
  { icon: Phone, label: 'Phone', value: '+1 (800) 555-0142' },
  { icon: MapPin, label: 'Atelier', value: '18 Madison Ave, New York, NY' },
]

export default function ContactPage() {
  const [sent, setSent] = useState(false)

  return (
    <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
      <Reveal className="max-w-2xl">
        <p className="text-sm tracking-widest text-accent uppercase">
          Get in touch
        </p>
        <h1 className="mt-3 font-heading text-4xl text-balance sm:text-5xl">
          We&apos;d love to hear from you
        </h1>
        <p className="mt-4 text-pretty text-muted-foreground">
          Whether you need help choosing a timepiece or have a question about
          your order, our concierge team is here to help.
        </p>
      </Reveal>

      <div className="mt-12 grid gap-10 lg:grid-cols-[1fr_1.4fr]">
        <div className="flex flex-col gap-6">
          {details.map((d) => (
            <div key={d.label} className="flex items-start gap-4">
              <span className="flex size-11 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                <d.icon className="size-5" />
              </span>
              <div>
                <p className="text-sm text-muted-foreground">{d.label}</p>
                <p className="font-medium">{d.value}</p>
              </div>
            </div>
          ))}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault()
            setSent(true)
          }}
          className="rounded-2xl border border-border bg-card p-6 sm:p-8"
        >
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Name" id="name" />
            <Field label="Email" id="email" type="email" />
          </div>
          <div className="mt-5">
            <label htmlFor="message" className="mb-2 block text-sm font-medium">
              Message
            </label>
            <textarea
              id="message"
              required
              rows={5}
              className="w-full resize-none rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none transition-colors focus:border-primary"
            />
          </div>
          <Button type="submit" size="lg" className="mt-6 w-full">
            {sent ? 'Message sent' : 'Send message'}
          </Button>
        </form>
      </div>
    </div>
  )
}

function Field({
  label,
  id,
  type = 'text',
}: {
  label: string
  id: string
  type?: string
}) {
  return (
    <div>
      <label htmlFor={id} className="mb-2 block text-sm font-medium">
        {label}
      </label>
      <input
        id={id}
        type={type}
        required
        className="h-10 w-full rounded-lg border border-border bg-background px-3 text-sm outline-none transition-colors focus:border-primary"
      />
    </div>
  )
}
