import { Hero } from '@/components/home/hero'
import { FeaturedCategories } from '@/components/home/featured-categories'
import { Bestsellers } from '@/components/home/bestsellers'
import { TrustSignals } from '@/components/home/trust-signals'

export default function HomePage() {
  return (
    <>
      <Hero />
      <FeaturedCategories />
      <Bestsellers />
      <TrustSignals />
    </>
  )
}
