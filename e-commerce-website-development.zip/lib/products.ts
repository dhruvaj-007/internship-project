export type Category = 'Men' | 'Women' | 'Smart' | 'Luxury'

export type Product = {
  slug: string
  name: string
  brand: string
  price: number
  category: Category
  style: string
  movement: 'Automatic' | 'Quartz' | 'Manual' | 'Smart'
  caseMaterial: string
  strapMaterial: string
  caseSize: string
  waterResistance: string
  glass: string
  image: string
  rating: number
  reviewCount: number
  bestseller: boolean
  description: string
  highlights: string[]
}

export const reviews = [
  {
    author: 'Jonathan M.',
    rating: 5,
    title: 'Exceptional craftsmanship',
    body: 'The finishing is flawless and it feels even better on the wrist than in photos. Shipping was fast and packaging was immaculate.',
    date: 'March 2026',
  },
  {
    author: 'Priya S.',
    rating: 5,
    title: 'Worth every penny',
    body: 'I have owned several timepieces and this rivals brands twice the price. The dial catches the light beautifully.',
    date: 'February 2026',
  },
  {
    author: 'Daniel R.',
    rating: 4,
    title: 'Stunning, runs slightly fast',
    body: 'Gorgeous watch and great accuracy after regulation. Took one star off only for the initial timing.',
    date: 'January 2026',
  },
]

export const products: Product[] = [
  {
    slug: 'obsidian-diver',
    name: 'Obsidian Diver 300M',
    brand: 'Chronos Elite',
    price: 2450,
    category: 'Men',
    style: 'Divers',
    movement: 'Automatic',
    caseMaterial: 'Stainless Steel',
    strapMaterial: 'Steel Bracelet',
    caseSize: '42mm',
    waterResistance: '300m',
    glass: 'Sapphire Crystal',
    image: '/watches/obsidian-diver.png',
    rating: 4.9,
    reviewCount: 214,
    bestseller: true,
    description:
      'A professional-grade dive watch with a luminous emerald dial, unidirectional bezel and a robust automatic movement engineered for the deep.',
    highlights: [
      'In-house automatic caliber, 72h reserve',
      'Unidirectional 120-click ceramic bezel',
      'Super-LumiNova hands and markers',
    ],
  },
  {
    slug: 'meridian-chronograph',
    name: 'Meridian Chronograph',
    brand: 'Chronos Elite',
    price: 3180,
    category: 'Men',
    style: 'Chronographs',
    movement: 'Automatic',
    caseMaterial: 'Stainless Steel',
    strapMaterial: 'Leather',
    caseSize: '41mm',
    waterResistance: '100m',
    glass: 'Sapphire Crystal',
    image: '/watches/meridian-chrono.png',
    rating: 4.8,
    reviewCount: 168,
    bestseller: true,
    description:
      'A refined three-register chronograph pairing a silver-white dial with a supple black leather strap for the modern gentleman.',
    highlights: [
      'Column-wheel chronograph movement',
      'Tachymeter scale and date complication',
      'Hand-stitched Italian leather strap',
    ],
  },
  {
    slug: 'aurora-dress',
    name: 'Aurora Dress',
    brand: 'Chronos Elite',
    price: 1890,
    category: 'Women',
    style: 'Dress Watches',
    movement: 'Quartz',
    caseMaterial: 'Rose Gold PVD',
    strapMaterial: 'Mesh',
    caseSize: '34mm',
    waterResistance: '50m',
    glass: 'Sapphire Crystal',
    image: '/watches/aurora-dress.png',
    rating: 4.9,
    reviewCount: 132,
    bestseller: true,
    description:
      'An elegant slim dress watch with a mother-of-pearl dial and a delicate rose gold mesh bracelet that flatters any wrist.',
    highlights: [
      'Genuine mother-of-pearl dial',
      'Ultra-slim 7mm rose gold case',
      'Adjustable Milanese mesh bracelet',
    ],
  },
  {
    slug: 'pulse-smart',
    name: 'Pulse Smart Pro',
    brand: 'Chronos Elite',
    price: 749,
    category: 'Smart',
    style: 'Smart',
    movement: 'Smart',
    caseMaterial: 'Titanium',
    strapMaterial: 'Fluoroelastomer',
    caseSize: '45mm',
    waterResistance: '50m',
    glass: 'Sapphire Crystal',
    image: '/watches/pulse-smart.png',
    rating: 4.7,
    reviewCount: 389,
    bestseller: true,
    description:
      'A titanium smartwatch with an always-on AMOLED display, advanced health sensors and multi-day battery life.',
    highlights: [
      'Always-on AMOLED retina display',
      'ECG, SpO2 and continuous heart-rate',
      'Up to 4 days battery life',
    ],
  },
  {
    slug: 'regent-tourbillon',
    name: 'Regent Tourbillon',
    brand: 'Chronos Elite',
    price: 12800,
    category: 'Luxury',
    style: 'Dress Watches',
    movement: 'Manual',
    caseMaterial: '18k Gold',
    strapMaterial: 'Alligator Leather',
    caseSize: '40mm',
    waterResistance: '30m',
    glass: 'Sapphire Crystal',
    image: '/watches/regent-tourbillon.png',
    rating: 5,
    reviewCount: 47,
    bestseller: false,
    description:
      'A flying tourbillon masterpiece in solid 18k gold, finished entirely by hand and limited to a select few collectors.',
    highlights: [
      'Hand-finished flying tourbillon',
      'Solid 18k gold case',
      'Limited edition, individually numbered',
    ],
  },
  {
    slug: 'solstice-gmt',
    name: 'Solstice GMT',
    brand: 'Chronos Elite',
    price: 2980,
    category: 'Men',
    style: 'Divers',
    movement: 'Automatic',
    caseMaterial: 'Stainless Steel',
    strapMaterial: 'Steel Bracelet',
    caseSize: '40mm',
    waterResistance: '200m',
    glass: 'Sapphire Crystal',
    image: '/watches/solstice-gmt.png',
    rating: 4.8,
    reviewCount: 121,
    bestseller: false,
    description:
      'A versatile travel companion featuring a striking blue dial and a true GMT complication for tracking a second time zone.',
    highlights: [
      'True GMT caliber with jumping hour hand',
      '24-hour two-tone bezel',
      'Brushed and polished steel bracelet',
    ],
  },
  {
    slug: 'lumen-skeleton',
    name: 'Lumen Skeleton',
    brand: 'Chronos Elite',
    price: 5400,
    category: 'Luxury',
    style: 'Dress Watches',
    movement: 'Automatic',
    caseMaterial: 'Stainless Steel',
    strapMaterial: 'Leather',
    caseSize: '41mm',
    waterResistance: '50m',
    glass: 'Sapphire Crystal',
    image: '/watches/lumen-skeleton.png',
    rating: 4.9,
    reviewCount: 76,
    bestseller: false,
    description:
      'An open-worked skeleton watch revealing every gear and bridge of its meticulously decorated automatic movement.',
    highlights: [
      'Fully skeletonized automatic movement',
      'Anglage and Côtes de Genève finishing',
      'Sapphire display caseback',
    ],
  },
  {
    slug: 'nova-smart',
    name: 'Nova Smart',
    brand: 'Chronos Elite',
    price: 629,
    category: 'Women',
    style: 'Smart',
    movement: 'Smart',
    caseMaterial: 'Rose Gold Aluminum',
    strapMaterial: 'Silicone',
    caseSize: '38mm',
    waterResistance: '50m',
    glass: 'Ion-X Glass',
    image: '/watches/nova-smart.png',
    rating: 4.6,
    reviewCount: 204,
    bestseller: false,
    description:
      'A slim, lightweight smartwatch designed for everyday wellness with elegant rose gold styling and customizable faces.',
    highlights: [
      'Sleep, stress and cycle tracking',
      'Interchangeable quick-release bands',
      'Lightweight 38mm rose gold case',
    ],
  },
]

export const categories: {
  name: string
  href: string
  filter: Category
}[] = [
  { name: 'Men', href: '/collections/men', filter: 'Men' },
  { name: 'Women', href: '/collections/women', filter: 'Women' },
  { name: 'Smart', href: '/collections/smart', filter: 'Smart' },
  { name: 'Luxury', href: '/collections/luxury', filter: 'Luxury' },
]

export const featuredStyles = [
  {
    name: 'Divers',
    description: 'Built for the depths',
    image: '/watches/obsidian-diver.png',
  },
  {
    name: 'Chronographs',
    description: 'Precision in motion',
    image: '/watches/meridian-chrono.png',
  },
  {
    name: 'Dress Watches',
    description: 'Understated elegance',
    image: '/watches/aurora-dress.png',
  },
]

export function getProduct(slug: string) {
  return products.find((p) => p.slug === slug)
}

export function getRelated(slug: string, category: Category) {
  return products
    .filter((p) => p.slug !== slug && p.category === category)
    .slice(0, 4)
}

export function formatPrice(price: number) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(price)
}
