import { Star } from 'lucide-react'
import { reviews } from '@/lib/products'

function Stars({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5 text-accent" aria-label={`${rating} out of 5 stars`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`size-4 ${i < rating ? 'fill-current' : 'text-muted-foreground'}`}
        />
      ))}
    </div>
  )
}

export function ReviewsSection({
  rating,
  reviewCount,
}: {
  rating: number
  reviewCount: number
}) {
  return (
    <section className="mt-16">
      <div className="mb-8 flex flex-wrap items-end justify-between gap-4 border-b border-border pb-6">
        <div>
          <h2 className="font-heading text-2xl">Customer Reviews</h2>
          <div className="mt-2 flex items-center gap-3">
            <Stars rating={Math.round(rating)} />
            <span className="text-sm text-muted-foreground">
              {rating.toFixed(1)} average · {reviewCount} reviews
            </span>
          </div>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {reviews.map((review) => (
          <article
            key={review.author}
            className="flex flex-col gap-3 rounded-xl border border-border bg-card p-6"
          >
            <Stars rating={review.rating} />
            <h3 className="font-heading text-lg leading-tight">
              {review.title}
            </h3>
            <p className="flex-1 text-pretty text-sm leading-relaxed text-muted-foreground">
              {review.body}
            </p>
            <footer className="text-sm text-muted-foreground">
              <span className="text-foreground">{review.author}</span> ·{' '}
              {review.date}
            </footer>
          </article>
        ))}
      </div>
    </section>
  )
}
