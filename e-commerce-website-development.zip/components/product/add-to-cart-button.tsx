'use client'

import { ShoppingBag } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useCart } from '@/components/cart/cart-provider'
import type { Product } from '@/lib/products'

export function AddToCartButton({ product }: { product: Product }) {
  const { addItem } = useCart()
  return (
    <Button
      size="lg"
      className="h-12 flex-1 text-base"
      onClick={() => addItem(product)}
    >
      <ShoppingBag className="size-5" />
      Add to Cart
    </Button>
  )
}
