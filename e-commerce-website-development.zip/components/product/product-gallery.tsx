'use client'

import { useState } from 'react'
import Image from 'next/image'

export function ProductGallery({
  image,
  name,
}: {
  image: string
  name: string
}) {
  const [zoom, setZoom] = useState(false)
  const [pos, setPos] = useState({ x: 50, y: 50 })

  const onMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * 100
    const y = ((e.clientY - rect.top) / rect.height) * 100
    setPos({ x, y })
  }

  // The same product shot framed three ways for a simple gallery.
  const thumbStyles = ['object-cover', 'object-contain p-6', 'object-cover scale-110']
  const [active, setActive] = useState(0)

  return (
    <div className="flex flex-col gap-4">
      <div
        onMouseEnter={() => setZoom(true)}
        onMouseLeave={() => setZoom(false)}
        onMouseMove={onMove}
        className="relative aspect-square cursor-zoom-in overflow-hidden rounded-2xl border border-border bg-card"
      >
        <Image
          src={image || '/placeholder.svg'}
          alt={name}
          fill
          priority
          sizes="(max-width: 1024px) 100vw, 50vw"
          className={`h-full w-full transition-transform duration-200 ${thumbStyles[active]}`}
          style={
            zoom
              ? {
                  transform: 'scale(2)',
                  transformOrigin: `${pos.x}% ${pos.y}%`,
                }
              : undefined
          }
        />
      </div>

      <div className="grid grid-cols-3 gap-4">
        {thumbStyles.map((style, i) => (
          <button
            key={i}
            onClick={() => setActive(i)}
            aria-label={`View angle ${i + 1}`}
            className={`relative aspect-square overflow-hidden rounded-xl border bg-card transition-colors ${
              active === i ? 'border-primary' : 'border-border hover:border-primary/40'
            }`}
          >
            <Image
              src={image || '/placeholder.svg'}
              alt={`${name} angle ${i + 1}`}
              fill
              sizes="120px"
              className={style}
            />
          </button>
        ))}
      </div>
    </div>
  )
}
