import Image from 'next/image'
import Link from 'next/link'
import { ChevronRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function Hero() {
  return (
    <section className="relative -mt-16 flex min-h-[92vh] items-center overflow-hidden">
      <Image
        src="/watches/hero.png"
        alt="A luxury emerald-dial diver watch worn on the wrist"
        fill
        priority
        sizes="100vw"
        className="object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-background/20" />
      <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />

      <div className="relative mx-auto w-full max-w-7xl px-4 pt-16 sm:px-6 lg:px-8">
        <div className="max-w-xl">
          <p className="mb-4 inline-flex items-center rounded-full border border-border bg-card/50 px-3 py-1 text-xs tracking-widest text-accent uppercase backdrop-blur">
            New Collection 2026
          </p>
          <h1 className="font-heading text-5xl leading-[1.05] text-balance sm:text-6xl lg:text-7xl">
            Time, perfected to the second.
          </h1>
          <p className="mt-6 max-w-md text-pretty text-lg leading-relaxed text-muted-foreground">
            Discover meticulously engineered luxury and smart timepieces,
            crafted for those who measure life in moments worth keeping.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <Button
              size="lg"
              className="h-11 px-6 text-base"
              nativeButton={false}
              render={<Link href="/collections/luxury" />}
            >
              Shop the Collection
              <ChevronRight className="size-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="h-11 px-6 text-base"
              nativeButton={false}
              render={<Link href="/collections/smart" />}
            >
              Explore Smart Watches
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
