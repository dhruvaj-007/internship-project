import Image from 'next/image'
import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { Reveal } from '@/components/reveal'
import { featuredStyles } from '@/lib/products'

export function FeaturedCategories() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
      <Reveal className="mb-10 flex flex-col gap-3 text-center">
        <h2 className="font-heading text-3xl text-balance sm:text-4xl">
          Find your signature style
        </h2>
        <p className="mx-auto max-w-xl text-pretty text-muted-foreground">
          From rugged divers to refined dress watches, every Chronos Elite
          timepiece is built to be worn for a lifetime.
        </p>
      </Reveal>

      <div className="grid gap-6 md:grid-cols-3">
        {featuredStyles.map((style, i) => (
          <Reveal key={style.name} delay={i * 100}>
            <Link
              href="/collections/men"
              className="group relative flex aspect-[4/5] flex-col justify-end overflow-hidden rounded-2xl border border-border"
            >
              <Image
                src={style.image || '/placeholder.svg'}
                alt={style.name}
                fill
                sizes="(max-width: 768px) 100vw, 33vw"
                className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
              <div className="relative p-6">
                <p className="text-sm text-accent">{style.description}</p>
                <h3 className="mt-1 flex items-center gap-2 font-heading text-2xl">
                  {style.name}
                  <ArrowRight className="size-5 transition-transform group-hover:translate-x-1" />
                </h3>
              </div>
            </Link>
          </Reveal>
        ))}
      </div>
    </section>
  )
}
