import { BadgeCheck, ShieldCheck, Truck } from 'lucide-react'
import { Reveal } from '@/components/reveal'

const signals = [
  {
    icon: Truck,
    title: 'Free Global Shipping',
    description: 'Insured, tracked delivery to your door, anywhere in the world.',
  },
  {
    icon: ShieldCheck,
    title: '2-Year Warranty',
    description: 'Every movement is covered by our comprehensive guarantee.',
  },
  {
    icon: BadgeCheck,
    title: 'Authenticity Guaranteed',
    description: 'Each timepiece ships with a certificate of authenticity.',
  },
]

export function TrustSignals() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
      <div className="grid gap-6 md:grid-cols-3">
        {signals.map((signal, i) => (
          <Reveal key={signal.title} delay={i * 100}>
            <div className="flex h-full flex-col items-center gap-3 rounded-2xl border border-border bg-card p-8 text-center">
              <span className="flex size-12 items-center justify-center rounded-full bg-primary/10 text-primary">
                <signal.icon className="size-6" />
              </span>
              <h3 className="font-heading text-lg">{signal.title}</h3>
              <p className="text-pretty text-sm leading-relaxed text-muted-foreground">
                {signal.description}
              </p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  )
}
