'use client'

import { useRef } from 'react'
import Link from 'next/link'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ProductCard } from '@/components/product-card'
import { Reveal } from '@/components/reveal'
import { products } from '@/lib/products'

export function Bestsellers() {
  const scroller = useRef<HTMLDivElement>(null)
  const bestsellers = products.filter((p) => p.bestseller)

  const scroll = (dir: 1 | -1) => {
    scroller.current?.scrollBy({ left: dir * 320, behavior: 'smooth' })
  }

  return (
    <section className="border-y border-border bg-card/40 py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal className="mb-10 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-sm tracking-widest text-accent uppercase">
              Most Coveted
            </p>
            <h2 className="mt-2 font-heading text-3xl text-balance sm:text-4xl">
              Bestselling timepieces
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              aria-label="Scroll left"
              onClick={() => scroll(-1)}
            >
              <ChevronLeft className="size-5" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              aria-label="Scroll right"
              onClick={() => scroll(1)}
            >
              <ChevronRight className="size-5" />
            </Button>
          </div>
        </Reveal>

        <div
          ref={scroller}
          className="flex snap-x snap-mandatory gap-6 overflow-x-auto pb-4 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
        >
          {bestsellers.map((product) => (
            <div
              key={product.slug}
              className="w-64 shrink-0 snap-start sm:w-72"
            >
              <ProductCard product={product} />
            </div>
          ))}
        </div>

        <div className="mt-8 text-center">
          <Button
            variant="outline"
            size="lg"
            nativeButton={false}
            render={<Link href="/collections/men" />}
          >
            View all watches
          </Button>
        </div>
      </div>
    </section>
  )
}
