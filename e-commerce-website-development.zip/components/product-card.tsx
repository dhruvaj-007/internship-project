'use client'

import Image from 'next/image'
import Link from 'next/link'
import { Plus, Star } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useCart } from '@/components/cart/cart-provider'
import { formatPrice, type Product } from '@/lib/products'

export function ProductCard({ product }: { product: Product }) {
  const { addItem } = useCart()

  return (
    <div className="group relative flex flex-col overflow-hidden rounded-xl border border-border bg-card transition-colors hover:border-primary/40">
      <Link
        href={`/products/${product.slug}`}
        className="relative aspect-square overflow-hidden bg-background"
      >
        <Image
          src={product.image || '/placeholder.svg'}
          alt={product.name}
          fill
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
          className="object-cover transition-transform duration-500 ease-out group-hover:scale-110"
        />
        {product.bestseller && (
          <span className="absolute top-3 left-3 rounded-full bg-accent px-2.5 py-1 text-xs font-medium text-accent-foreground">
            Bestseller
          </span>
        )}
      </Link>

      <div className="flex flex-1 flex-col p-4">
        <div className="flex items-center gap-1 text-accent">
          <Star className="size-3.5 fill-current" />
          <span className="text-xs text-muted-foreground">
            {product.rating.toFixed(1)} ({product.reviewCount})
          </span>
        </div>
        <Link href={`/products/${product.slug}`} className="mt-1">
          <h3 className="font-heading text-base leading-tight text-balance transition-colors group-hover:text-primary">
            {product.name}
          </h3>
        </Link>
        <p className="mt-1 text-sm text-muted-foreground">
          {product.style} · {product.movement}
        </p>

        <div className="mt-4 flex items-center justify-between gap-2">
          <span className="font-heading text-lg tabular-nums">
            {formatPrice(product.price)}
          </span>
          <Button
            size="sm"
            aria-label={`Add ${product.name} to cart`}
            onClick={() => addItem(product)}
          >
            <Plus className="size-4" />
            Add
          </Button>
        </div>
      </div>
    </div>
  )
}
