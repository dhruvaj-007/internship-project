'use client'

import Image from 'next/image'
import { Minus, Plus, ShoppingBag, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { formatPrice } from '@/lib/products'
import { useCart } from './cart-provider'

export function CartDrawer() {
  const {
    items,
    isOpen,
    closeCart,
    subtotal,
    count,
    removeItem,
    updateQuantity,
  } = useCart()

  return (
    <>
      <div
        aria-hidden={!isOpen}
        onClick={closeCart}
        className={`fixed inset-0 z-50 bg-background/70 backdrop-blur-sm transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
      />
      <aside
        role="dialog"
        aria-label="Shopping cart"
        aria-modal={isOpen}
        className={`fixed top-0 right-0 z-50 flex h-full w-full max-w-md flex-col border-l border-border bg-card transition-transform duration-300 ease-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <header className="flex items-center justify-between border-b border-border px-6 py-5">
          <h2 className="flex items-center gap-2 font-heading text-lg">
            <ShoppingBag className="size-5 text-primary" />
            Your Cart
            <span className="text-muted-foreground">({count})</span>
          </h2>
          <Button
            variant="ghost"
            size="icon"
            onClick={closeCart}
            aria-label="Close cart"
          >
            <X className="size-5" />
          </Button>
        </header>

        {items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-3 px-6 text-center">
            <ShoppingBag className="size-10 text-muted-foreground" />
            <p className="text-muted-foreground">Your cart is empty.</p>
            <Button variant="outline" onClick={closeCart}>
              Continue shopping
            </Button>
          </div>
        ) : (
          <>
            <ul className="flex-1 divide-y divide-border overflow-y-auto px-6">
              {items.map(({ product, quantity }) => (
                <li key={product.slug} className="flex gap-4 py-5">
                  <div className="relative size-20 shrink-0 overflow-hidden rounded-md bg-background">
                    <Image
                      src={product.image || '/placeholder.svg'}
                      alt={product.name}
                      fill
                      sizes="80px"
                      className="object-cover"
                    />
                  </div>
                  <div className="flex flex-1 flex-col">
                    <div className="flex justify-between gap-2">
                      <div>
                        <p className="font-medium leading-tight">
                          {product.name}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {product.style}
                        </p>
                      </div>
                      <button
                        onClick={() => removeItem(product.slug)}
                        aria-label={`Remove ${product.name}`}
                        className="text-muted-foreground transition-colors hover:text-foreground"
                      >
                        <X className="size-4" />
                      </button>
                    </div>
                    <div className="mt-auto flex items-center justify-between">
                      <div className="flex items-center rounded-md border border-border">
                        <button
                          aria-label="Decrease quantity"
                          onClick={() =>
                            updateQuantity(product.slug, quantity - 1)
                          }
                          className="flex size-8 items-center justify-center text-muted-foreground transition-colors hover:text-foreground"
                        >
                          <Minus className="size-3.5" />
                        </button>
                        <span className="w-8 text-center text-sm tabular-nums">
                          {quantity}
                        </span>
                        <button
                          aria-label="Increase quantity"
                          onClick={() =>
                            updateQuantity(product.slug, quantity + 1)
                          }
                          className="flex size-8 items-center justify-center text-muted-foreground transition-colors hover:text-foreground"
                        >
                          <Plus className="size-3.5" />
                        </button>
                      </div>
                      <span className="font-medium tabular-nums">
                        {formatPrice(product.price * quantity)}
                      </span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>

            <footer className="border-t border-border px-6 py-5">
              <div className="mb-1 flex items-center justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="font-heading text-xl tabular-nums">
                  {formatPrice(subtotal)}
                </span>
              </div>
              <p className="mb-4 text-xs text-muted-foreground">
                Shipping and taxes calculated at checkout. Free global shipping.
              </p>
              <Button size="lg" className="w-full">
                Secure Checkout
              </Button>
            </footer>
          </>
        )}
      </aside>
    </>
  )
}
