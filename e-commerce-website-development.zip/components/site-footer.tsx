'use client'

import { useState } from 'react'
import Link from 'next/link'
import { AtSign, Send, Share2, Watch } from 'lucide-react'
import { Button } from '@/components/ui/button'

const footerLinks = {
  Collections: [
    { name: 'Men', href: '/collections/men' },
    { name: 'Women', href: '/collections/women' },
    { name: 'Smart', href: '/collections/smart' },
    { name: 'Luxury', href: '/collections/luxury' },
  ],
  Company: [
    { name: 'About Us', href: '/about' },
    { name: 'Contact', href: '/contact' },
    { name: 'FAQs', href: '#' },
    { name: 'Authenticity', href: '#' },
  ],
  Support: [
    { name: 'Return Policy', href: '#' },
    { name: 'Shipping', href: '#' },
    { name: 'Terms of Service', href: '#' },
    { name: 'Privacy Policy', href: '#' },
  ],
}

export function SiteFooter() {
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)

  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.5fr_2fr]">
          <div className="max-w-sm">
            <Link href="/" className="flex items-center gap-2">
              <Watch className="size-6 text-primary" />
              <span className="font-heading text-lg tracking-wide">
                CHRONOS<span className="text-primary"> ELITE</span>
              </span>
            </Link>
            <p className="mt-4 text-pretty text-sm leading-relaxed text-muted-foreground">
              Curating the world&apos;s finest luxury and smart timepieces.
              Join our list for private releases and collector insights.
            </p>
            <form
              onSubmit={(e) => {
                e.preventDefault()
                if (email.trim()) setSubmitted(true)
              }}
              className="mt-6 flex gap-2"
            >
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                aria-label="Email address"
                className="h-9 w-full rounded-lg border border-border bg-background px-3 text-sm outline-none transition-colors focus:border-primary"
              />
              <Button type="submit" size="lg">
                {submitted ? 'Subscribed' : 'Subscribe'}
              </Button>
            </form>
          </div>

          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3">
            {Object.entries(footerLinks).map(([heading, links]) => (
              <div key={heading}>
                <h3 className="font-heading text-sm tracking-wide text-foreground">
                  {heading}
                </h3>
                <ul className="mt-4 flex flex-col gap-3">
                  {links.map((link) => (
                    <li key={link.name}>
                      <Link
                        href={link.href}
                        className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                      >
                        {link.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-border pt-8 sm:flex-row">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} Chronos Elite. All rights
            reserved.
          </p>
          <div className="flex items-center gap-4">
            {[AtSign, Send, Share2].map((Icon, i) => (
              <Link
                key={i}
                href="#"
                aria-label="Social media"
                className="text-muted-foreground transition-colors hover:text-primary"
              >
                <Icon className="size-5" />
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
