'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { Search, X } from 'lucide-react'
import { products, formatPrice } from '@/lib/products'

function fuzzyMatch(query: string, text: string) {
  const q = query.toLowerCase().replace(/\s+/g, '')
  const t = text.toLowerCase()
  if (!q) return false
  let i = 0
  for (const char of t) {
    if (char === q[i]) i++
    if (i === q.length) return true
  }
  return false
}

export function SearchDialog({
  open,
  onClose,
}: {
  open: boolean
  onClose: () => void
}) {
  const [query, setQuery] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (open) {
      setQuery('')
      const id = window.setTimeout(() => inputRef.current?.focus(), 50)
      return () => window.clearTimeout(id)
    }
  }, [open])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  const results = useMemo(() => {
    if (!query.trim()) return []
    return products
      .filter((p) =>
        [p.name, p.brand, p.category, p.style, p.movement].some(
          (field) =>
            field.toLowerCase().includes(query.toLowerCase()) ||
            fuzzyMatch(query, field),
        ),
      )
      .slice(0, 6)
  }, [query])

  if (!open) return null

  return (
    <div className="fixed inset-0 z-[60] flex justify-center px-4 pt-24">
      <div
        className="fixed inset-0 bg-background/70 backdrop-blur-sm"
        onClick={onClose}
        aria-hidden
      />
      <div
        role="dialog"
        aria-label="Search products"
        className="relative h-fit w-full max-w-xl overflow-hidden rounded-xl border border-border bg-card shadow-2xl"
      >
        <div className="flex items-center gap-3 border-b border-border px-4">
          <Search className="size-5 shrink-0 text-muted-foreground" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search divers, chronographs, smart watches..."
            className="h-14 w-full bg-transparent text-base outline-none placeholder:text-muted-foreground"
          />
          <button
            onClick={onClose}
            aria-label="Close search"
            className="text-muted-foreground transition-colors hover:text-foreground"
          >
            <X className="size-5" />
          </button>
        </div>

        {query.trim() && (
          <ul className="max-h-80 overflow-y-auto p-2">
            {results.length === 0 ? (
              <li className="px-3 py-6 text-center text-sm text-muted-foreground">
                No timepieces match "{query}".
              </li>
            ) : (
              results.map((p) => (
                <li key={p.slug}>
                  <Link
                    href={`/products/${p.slug}`}
                    onClick={onClose}
                    className="flex items-center gap-3 rounded-lg px-3 py-2.5 transition-colors hover:bg-muted"
                  >
                    <div className="relative size-12 shrink-0 overflow-hidden rounded-md bg-background">
                      <Image
                        src={p.image || '/placeholder.svg'}
                        alt={p.name}
                        fill
                        sizes="48px"
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium leading-tight">{p.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {p.category} · {p.style}
                      </p>
                    </div>
                    <span className="text-sm tabular-nums text-muted-foreground">
                      {formatPrice(p.price)}
                    </span>
                  </Link>
                </li>
              ))
            )}
          </ul>
        )}
      </div>
    </div>
  )
}
