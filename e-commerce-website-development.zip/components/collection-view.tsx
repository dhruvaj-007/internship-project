'use client'

import { useMemo, useState } from 'react'
import { SlidersHorizontal, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ProductCard } from '@/components/product-card'
import { Reveal } from '@/components/reveal'
import { products as allProducts, type Product } from '@/lib/products'

type SortKey = 'featured' | 'price-asc' | 'price-desc' | 'rating'

const sortOptions: { key: SortKey; label: string }[] = [
  { key: 'featured', label: 'Featured' },
  { key: 'price-asc', label: 'Price: Low to High' },
  { key: 'price-desc', label: 'Price: High to Low' },
  { key: 'rating', label: 'Top Rated' },
]

function unique<T>(arr: T[]) {
  return Array.from(new Set(arr))
}

function FilterGroup({
  title,
  options,
  selected,
  onToggle,
}: {
  title: string
  options: string[]
  selected: string[]
  onToggle: (value: string) => void
}) {
  return (
    <div className="border-b border-border py-5">
      <h3 className="mb-3 font-heading text-sm tracking-wide">{title}</h3>
      <div className="flex flex-col gap-2.5">
        {options.map((option) => (
          <label
            key={option}
            className="flex cursor-pointer items-center gap-2.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <input
              type="checkbox"
              checked={selected.includes(option)}
              onChange={() => onToggle(option)}
              className="size-4 rounded border-border accent-primary"
            />
            {option}
          </label>
        ))}
      </div>
    </div>
  )
}

export function CollectionView({
  title,
  description,
  products = allProducts,
}: {
  title: string
  description: string
  products?: Product[]
}) {
  const [movements, setMovements] = useState<string[]>([])
  const [caseMaterials, setCaseMaterials] = useState<string[]>([])
  const [strapMaterials, setStrapMaterials] = useState<string[]>([])
  const [maxPrice, setMaxPrice] = useState(15000)
  const [sort, setSort] = useState<SortKey>('featured')
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false)

  const movementOptions = unique(products.map((p) => p.movement))
  const caseOptions = unique(products.map((p) => p.caseMaterial))
  const strapOptions = unique(products.map((p) => p.strapMaterial))

  const toggle =
    (setter: React.Dispatch<React.SetStateAction<string[]>>) =>
    (value: string) =>
      setter((prev) =>
        prev.includes(value)
          ? prev.filter((v) => v !== value)
          : [...prev, value],
      )

  const filtered = useMemo(() => {
    const result = products.filter((p) => {
      if (movements.length && !movements.includes(p.movement)) return false
      if (caseMaterials.length && !caseMaterials.includes(p.caseMaterial))
        return false
      if (strapMaterials.length && !strapMaterials.includes(p.strapMaterial))
        return false
      if (p.price > maxPrice) return false
      return true
    })
    switch (sort) {
      case 'price-asc':
        return [...result].sort((a, b) => a.price - b.price)
      case 'price-desc':
        return [...result].sort((a, b) => b.price - a.price)
      case 'rating':
        return [...result].sort((a, b) => b.rating - a.rating)
      default:
        return [...result].sort(
          (a, b) => Number(b.bestseller) - Number(a.bestseller),
        )
    }
  }, [products, movements, caseMaterials, strapMaterials, maxPrice, sort])

  const clearAll = () => {
    setMovements([])
    setCaseMaterials([])
    setStrapMaterials([])
    setMaxPrice(15000)
  }

  const activeCount =
    movements.length +
    caseMaterials.length +
    strapMaterials.length +
    (maxPrice < 15000 ? 1 : 0)

  const sidebar = (
    <div>
      <div className="flex items-center justify-between border-b border-border pb-4">
        <h2 className="font-heading text-lg">Filters</h2>
        {activeCount > 0 && (
          <button
            onClick={clearAll}
            className="text-xs text-primary transition-opacity hover:opacity-80"
          >
            Clear all
          </button>
        )}
      </div>
      <div className="border-b border-border py-5">
        <h3 className="mb-3 font-heading text-sm tracking-wide">
          Max Price:{' '}
          <span className="text-primary tabular-nums">
            ${maxPrice.toLocaleString()}
          </span>
        </h3>
        <input
          type="range"
          min={500}
          max={15000}
          step={100}
          value={maxPrice}
          onChange={(e) => setMaxPrice(Number(e.target.value))}
          aria-label="Maximum price"
          className="w-full accent-primary"
        />
      </div>
      <FilterGroup
        title="Movement"
        options={movementOptions}
        selected={movements}
        onToggle={toggle(setMovements)}
      />
      <FilterGroup
        title="Case Material"
        options={caseOptions}
        selected={caseMaterials}
        onToggle={toggle(setCaseMaterials)}
      />
      <FilterGroup
        title="Strap Material"
        options={strapOptions}
        selected={strapMaterials}
        onToggle={toggle(setStrapMaterials)}
      />
    </div>
  )

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <Reveal className="mb-10">
        <p className="text-sm tracking-widest text-accent uppercase">
          Collection
        </p>
        <h1 className="mt-2 font-heading text-4xl text-balance sm:text-5xl">
          {title}
        </h1>
        <p className="mt-3 max-w-2xl text-pretty text-muted-foreground">
          {description}
        </p>
      </Reveal>

      <div className="flex flex-col gap-8 lg:flex-row">
        <aside className="hidden w-64 shrink-0 lg:block">
          <div className="sticky top-24">{sidebar}</div>
        </aside>

        <div className="flex-1">
          <div className="mb-6 flex items-center justify-between gap-4">
            <p className="text-sm text-muted-foreground">
              {filtered.length}{' '}
              {filtered.length === 1 ? 'timepiece' : 'timepieces'}
            </p>
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                className="lg:hidden"
                onClick={() => setMobileFiltersOpen(true)}
              >
                <SlidersHorizontal className="size-4" />
                Filters
                {activeCount > 0 && ` (${activeCount})`}
              </Button>
              <label className="sr-only" htmlFor="sort">
                Sort by
              </label>
              <select
                id="sort"
                value={sort}
                onChange={(e) => setSort(e.target.value as SortKey)}
                className="h-9 rounded-lg border border-border bg-card px-3 text-sm outline-none transition-colors focus:border-primary"
              >
                {sortOptions.map((option) => (
                  <option key={option.key} value={option.key}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {filtered.length === 0 ? (
            <div className="rounded-xl border border-border bg-card p-12 text-center text-muted-foreground">
              No timepieces match your filters.
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-5 lg:grid-cols-3">
              {filtered.map((product) => (
                <ProductCard key={product.slug} product={product} />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Mobile filter drawer */}
      <div
        className={`fixed inset-0 z-50 lg:hidden ${mobileFiltersOpen ? '' : 'pointer-events-none'}`}
        aria-hidden={!mobileFiltersOpen}
      >
        <div
          onClick={() => setMobileFiltersOpen(false)}
          className={`absolute inset-0 bg-background/70 backdrop-blur-sm transition-opacity ${
            mobileFiltersOpen ? 'opacity-100' : 'opacity-0'
          }`}
        />
        <div
          className={`absolute top-0 right-0 flex h-full w-80 max-w-[85vw] flex-col overflow-y-auto border-l border-border bg-card p-6 transition-transform duration-300 ${
            mobileFiltersOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
        >
          <div className="mb-2 flex items-center justify-between">
            <span className="font-heading text-lg">Filters</span>
            <Button
              variant="ghost"
              size="icon"
              aria-label="Close filters"
              onClick={() => setMobileFiltersOpen(false)}
            >
              <X className="size-5" />
            </Button>
          </div>
          {sidebar}
          <Button
            className="mt-6"
            size="lg"
            onClick={() => setMobileFiltersOpen(false)}
          >
            Show {filtered.length} results
          </Button>
        </div>
      </div>
    </div>
  )
}
