/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ClockProduct } from './types';

export const INITIAL_CLOCKS: ClockProduct[] = [
  {
    id: 'clk-01',
    name: 'The Heritage Ambassador Grandfather',
    category: 'Grandfather',
    price: 412250,
    description: 'A towering masterpiece of horological art. Crafted from hand-rubbed solid cherry wood, it features a moon phase dial, solid brass bezel, and a premium German cable-driven movement playing full Westminster, Whittington, and St. Michael chimes.',
    image: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&q=80&w=600',
    specs: {
      material: 'Solid North American Cherry & Beveled Glass',
      dimensions: '82" H x 24" W x 15" D',
      movement: '8-day German Cable-driven Mechanical',
      chime: 'Triple Chime (Westminster, St. Michael, Whittington)',
      origin: 'Black Forest region, Germany'
    },
    features: [
      'Automatic nighttime chime shut-off (10:00 PM - 7:00 AM)',
      'Illuminated dial for ambient night viewing',
      'Solid brass weights and highly polished pendulum bob',
      'Keepsake drawer built into base cabinet'
    ],
    rating: 4.9,
    reviewCount: 24,
    stock: 2
  },
  {
    id: 'clk-02',
    name: 'Tempus Fugit Oak Grandfather',
    category: 'Grandfather',
    price: 272000,
    description: 'Embrace timeless heritage with this classic Oak Grandfather clock. Features a vintage brushed-brass dial, Roman numeral indices, and a robust mechanical chain-driven pendulum movement. Designed to become a treasured family heirloom.',
    image: 'https://images.unsplash.com/photo-1540829016269-e05b709ea212?auto=format&fit=crop&q=80&w=600',
    specs: {
      material: 'Selected Appalachian Red Oak Wood',
      dimensions: '78" H x 20" W x 12" D',
      movement: '8-day Mechanical Chain-driven',
      chime: 'Westminster Chimes on every quarter hour',
      origin: 'Ohio, USA'
    },
    features: [
      'Polished brass dial with custom-etched corners',
      'Adjustable levelers on all four base corners',
      'Secured locked door with bevel glass inserts',
      'Adjustable chime volume controls'
    ],
    rating: 4.7,
    reviewCount: 18,
    stock: 3
  },
  {
    id: 'clk-03',
    name: 'Napoleon Brass Bracket Mantel',
    category: 'Mantel',
    price: 52700,
    description: 'An elegant addition to any library or fireplace mantel. Inspired by 19th-century French styles, this mantel clock features a gorgeous arched mahogany frame accented by polished brass inlays and a hand-wound mechanical movement.',
    image: 'https://images.unsplash.com/photo-1563861826100-9cb868fdbe1c?auto=format&fit=crop&q=80&w=600',
    specs: {
      material: 'Sapele Mahogany Wood, Mirror-polished Brass',
      dimensions: '11" H x 18" W x 6" D',
      movement: '8-day Key-wound Spring Mechanical',
      chime: 'Soft half-hour strike on coiled steel gong',
      origin: 'Jura, France'
    },
    features: [
      'Enamel clock-face with elegant Breguet-style hands',
      'Dual-wind mechanical movement (chime & time separate)',
      'Felt-padded brass feet to protect delicate surfaces',
      'Comes with a brass winding key in velvet pouch'
    ],
    rating: 4.8,
    reviewCount: 31,
    stock: 5
  },
  {
    id: 'clk-04',
    name: 'The Westminster Arch Mantel',
    category: 'Mantel',
    price: 38250,
    description: 'A stunning traditional tambour-style mantel clock. Featuring rich walnut veneers, a brushed silver chapter ring on a brass dial plate, and a high-accuracy mechanical key-wound movement with a classic Westminster acoustic chime.',
    image: 'https://images.unsplash.com/photo-1612817288484-6f916006741a?auto=format&fit=crop&q=80&w=600',
    specs: {
      material: 'Selected Walnut Veneer with Satin Finish',
      dimensions: '9" H x 16" W x 5" D',
      movement: '8-day Floating Balance Mechanical',
      chime: 'Progressive Westminster Chimes',
      origin: 'Warwickshire, England'
    },
    features: [
      'Satin gold metal dial with intricate corner carvings',
      'Automatic chime silencing feature at night',
      'Hinged rear door panel for easy timing adjustments',
      'Shatterproof mineral glass crystal cover'
    ],
    rating: 4.6,
    reviewCount: 15,
    stock: 7
  },
  {
    id: 'clk-05',
    name: 'The Regulator Pendulum Wall Clock',
    category: 'Wall',
    price: 32300,
    description: 'Modeled after historic 1880s regulator station clocks, this beautiful wall timepiece features a mahogany drop-dial case, a highly visible oscillating brass pendulum, and an accurate key-wound mechanical gong strike.',
    image: 'https://images.unsplash.com/photo-1518932945647-7a1c969f8be2?auto=format&fit=crop&q=80&w=600',
    specs: {
      material: 'Stained Mahogany Wood and Brass Finishings',
      dimensions: '26" H x 14" W x 5" D',
      movement: '15-day Heavy-duty Key-wind Mechanical',
      chime: 'Hourly Single-strike Bell Gong',
      origin: 'Geneva, Switzerland'
    },
    features: [
      'Elegant high-contrast Roman cream dial',
      'Hand-crafted wood carvings around the glass frame',
      'Extended 15-day reserve winding capacity',
      'Dual access side windows to view mechanical gearing'
    ],
    rating: 4.8,
    reviewCount: 42,
    stock: 4
  },
  {
    id: 'clk-06',
    name: 'Minimalist Slate Quartz Wall Clock',
    category: 'Wall',
    price: 15300,
    description: 'For modern minimalist spaces. Cut from a single slate of natural black schist stone, accented by solid walnut wooden hands. Driven by a silent-sweep quartz movement with zero ticking noise.',
    image: 'https://images.unsplash.com/photo-1522441815192-d9f04eb0615c?auto=format&fit=crop&q=80&w=600',
    specs: {
      material: 'Natural Italian Slate Stone & Walnut Wood',
      dimensions: '14" Diameter x 1.5" Depth',
      movement: 'High-torque Silent Sweep Quartz',
      chime: 'None (Silent operation)',
      origin: 'Trentino, Italy'
    },
    features: [
      'Each piece features a unique natural stone grain pattern',
      'Completely silent sweep second hand, perfect for bedrooms',
      'Battery-powered (1x AA battery, included)',
      'Integrated heavy-duty steel wall mounting bracket'
    ],
    rating: 4.5,
    reviewCount: 56,
    stock: 12
  },
  {
    id: 'clk-07',
    name: 'Black Forest Chalet Cuckoo Clock',
    category: 'Cuckoo',
    price: 63750,
    description: 'A genuine hand-carved Black Forest cuckoo clock. Modeled as a classic alpine timber chalet. Includes automated wood-chopper figures moving with the chime, dancing wooden figures rotating on the balcony, and an authentic wooden bellows cuckoo bird sound.',
    image: 'https://images.unsplash.com/photo-1534797258760-1bd2cc95a5bd?auto=format&fit=crop&q=80&w=600',
    specs: {
      material: 'Hand-carved Linden Wood, Brass Chains',
      dimensions: '15" H x 13" W x 8" D',
      movement: '1-day Regula Mechanical Chain-wound',
      chime: 'Cuckoo bird call & alternating Edelweiss / Happy Wanderer melodies',
      origin: 'Schonach, Black Forest, Germany'
    },
    features: [
      'Certified authentic by the VDS (Black Forest Clock Association)',
      'Automated waterwheel and woodchopper movement',
      'Manual night shut-off lever to disable bird and sound',
      'Cast-iron pinecone weights suspended on high-tensile chains'
    ],
    rating: 4.9,
    reviewCount: 19,
    stock: 2
  },
  {
    id: 'clk-08',
    name: 'Classic Oak Carved Cuckoo Clock',
    category: 'Cuckoo',
    price: 35700,
    description: 'A traditional and timeless design. Elegant, natural oak cuckoo clock featuring beautifully hand-carved oak leaves, forest birds, and an authentic wood bellows mechanism. Handcrafted by local artisans.',
    image: 'https://images.unsplash.com/photo-1601004890684-d8cbf643f5f2?auto=format&fit=crop&q=80&w=600',
    specs: {
      material: 'Hand-selected Solid Oak Wood',
      dimensions: '12" H x 9" W x 6" D',
      movement: '8-day Mechanical Chain-wound',
      chime: 'Cuckoo strike every half and full hour',
      origin: 'Triberg, Germany'
    },
    features: [
      'Detailed depth relief carvings',
      'Wooden cuckoo bird, wooden clock dial and hands',
      '8-day wind-up interval (only requires winding once a week)',
      'Lever for easy manual chime muting'
    ],
    rating: 4.7,
    reviewCount: 22,
    stock: 4
  },
  {
    id: 'clk-09',
    name: 'Gilded Brass Skeleton Table Clock',
    category: 'Table',
    price: 24650,
    description: 'An architectural table showpiece that reveals the pure mechanics of time. Features a glass dome housing an exposed polished golden brass movement. Observe the escapement, hairspring, and mainspring barrel interact in a slow dance.',
    image: 'https://images.unsplash.com/photo-1511216173030-c8683a658a01?auto=format&fit=crop&q=80&w=600',
    specs: {
      material: 'Polished Brass Frame, Mouth-blown Glass Dome',
      dimensions: '10" H x 6" Diameter',
      movement: '8-day Pass Strike Spring Mechanical',
      chime: 'Delicate single strike on the hour gong',
      origin: 'Kyoto, Japan'
    },
    features: [
      'Exposed tourbillon-style balance wheel visible at top',
      'Gold plated gear train and escape wheel',
      'Heavy velvet-lined brass base for stability',
      'Comes with custom micro-fiber polishing glove'
    ],
    rating: 4.9,
    reviewCount: 37,
    stock: 6
  },
  {
    id: 'clk-10',
    name: 'Art Deco Brass Desk Chronometer',
    category: 'Table',
    price: 11900,
    description: 'A compact but striking timepiece drawing inspiration from 1930s Parisian styling. Combining heavy brushed brass casing, stepped geometric pillars, and a high-precision ticking mechanism.',
    image: 'https://images.unsplash.com/photo-1585128719715-46776b56a0d1?auto=format&fit=crop&q=80&w=600',
    specs: {
      material: 'Solid Brass Casing & Silver Dial Plate',
      dimensions: '5" H x 6.5" W x 2" D',
      movement: 'Jeweled Quartz Movement (Super-precision)',
      chime: 'None (Silent operation)',
      origin: 'La Chaux-de-Fonds, Switzerland'
    },
    features: [
      'Solid heavy-gauge brass body weighing nearly 2 lbs',
      'Deep emerald-colored metal hands contrast the dial',
      'Non-reflective crystal sapphire glass',
      'Perfect centerpiece for desks, nightstands, or bookshelves'
    ],
    rating: 4.6,
    reviewCount: 14,
    stock: 10
  }
];
