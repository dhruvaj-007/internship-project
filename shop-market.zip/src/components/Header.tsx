/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useStore } from '../store';
import { Clock, ShoppingBag, Calendar, List, Layers, Menu, ChevronDown, Info } from 'lucide-react';

export default function Header() {
  const { activeTab, setActiveTab, cart, bookings, setAboutOpen, resetFilters, setShowHero } = useStore();
  const [menuOpen, setMenuOpen] = React.useState(false);

  const totalCartItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const activeBookingsCount = bookings.filter(b => b.status !== 'completed').length;

  return (
    <header className="sticky top-0 z-50 bg-slate-900/95 backdrop-blur-md border-b border-amber-950/30 text-slate-100 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Logo / Brand Brand */}
        <div 
          onClick={() => {
            setShowHero(true);
            setActiveTab('catalog');
          }} 
          className="flex items-center space-x-3 cursor-pointer group select-none"
          id="header-logo"
        >
          <div className="p-2.5 bg-amber-950/40 border border-amber-600/30 rounded-lg group-hover:border-amber-500 transition-all">
            <Clock className="w-6 h-6 text-amber-500 animate-[spin_60s_linear_infinite]" />
          </div>
          <div>
            <h1 className="font-serif text-xl sm:text-2xl tracking-wide font-semibold text-white group-hover:text-amber-400 transition-colors">
              SHOP <span className="font-sans text-xs font-light tracking-widest text-amber-500 block -mt-1 sm:inline sm:mt-0 sm:ml-2">MARKET</span>
            </h1>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-1 lg:space-x-2 text-sm font-medium">
          <button
            id="nav-catalog"
            onClick={() => {
              setShowHero(false);
              setActiveTab('catalog');
            }}
            className={`px-4 py-2 rounded-full transition-all duration-200 ${
              activeTab === 'catalog' || activeTab === 'order-success'
                ? 'bg-amber-600/10 text-amber-400 border border-amber-500/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60 border border-transparent'
            }`}
          >
            Clock Catalog
          </button>
          
          <button
            id="nav-repairs"
            onClick={() => setActiveTab('repairs')}
            className={`px-4 py-2 rounded-full transition-all duration-200 flex items-center space-x-1.5 ${
              activeTab === 'repairs' || activeTab === 'booking-success'
                ? 'bg-amber-600/10 text-amber-400 border border-amber-500/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60 border border-transparent'
            }`}
          >
            <Calendar className="w-4 h-4 text-amber-500/80" />
            <span>Repair Workshop</span>
          </button>

          {bookings.length > 0 && (
            <button
              id="nav-bookings-list"
              onClick={() => setActiveTab('bookings-list')}
              className={`px-4 py-2 rounded-full transition-all duration-200 flex items-center space-x-1.5 ${
                activeTab === 'bookings-list'
                  ? 'bg-amber-600/10 text-amber-400 border border-amber-500/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60 border border-transparent'
              }`}
            >
              <List className="w-4 h-4 text-amber-500/80" />
              <span>My Bookings</span>
              {activeBookingsCount > 0 && (
                <span className="ml-1 bg-amber-500 text-slate-950 text-xxs font-bold px-1.5 py-0.5 rounded-full">
                  {activeBookingsCount}
                </span>
              )}
            </button>
          )}
        </nav>

        {/* Right Corner Buttons: Cart & Quick Contact */}
        <div className="flex items-center space-x-3">
          <button
            id="header-cart-btn"
            onClick={() => setActiveTab('cart')}
            className={`relative p-2.5 rounded-full transition-all flex items-center justify-center border ${
              activeTab === 'cart' || activeTab === 'checkout'
                ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-lg shadow-amber-500/10'
                : 'bg-slate-800/80 text-slate-200 border-slate-700/60 hover:text-white hover:bg-slate-700 hover:border-slate-600'
            }`}
            aria-label="Shopping Cart"
          >
            <ShoppingBag className="w-5 h-5" />
            {totalCartItems > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-xs font-bold w-5.5 h-5.5 rounded-full flex items-center justify-center border-2 border-slate-900 animate-pulse">
                {totalCartItems}
              </span>
            )}
          </button>

          {/* Right Upper Side Dropdown Menu Button */}
          <div className="relative">
            <button
              id="header-menu-btn"
              onClick={() => setMenuOpen(!menuOpen)}
              className={`flex items-center space-x-1 py-2.5 px-3 rounded-full border text-xs font-semibold uppercase tracking-wider transition-all duration-200 ${
                menuOpen
                  ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-lg'
                  : 'bg-slate-800/80 text-slate-200 border-slate-700/60 hover:text-white hover:bg-slate-700 hover:border-slate-600'
              }`}
              aria-label="Atelier Menu"
            >
              <Menu className="w-4 h-4" />
              <span className="hidden sm:inline">Menu</span>
              <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${menuOpen ? 'rotate-180' : ''}`} />
            </button>

            {menuOpen && (
              <>
                {/* Backdrop overlay */}
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setMenuOpen(false)}
                />
                
                {/* Dropdown items */}
                <div 
                  id="header-menu-dropdown"
                  className="absolute right-0 mt-2 w-48 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl p-1 z-50 origin-top-right transition-all"
                >
                  <button
                    onClick={() => {
                      setAboutOpen(true);
                      setMenuOpen(false);
                    }}
                    className="w-full flex items-center space-x-2.5 px-3 py-2.5 rounded-lg text-left text-xs font-semibold tracking-wider uppercase text-slate-300 hover:text-amber-400 hover:bg-slate-800/60 transition-colors"
                  >
                    <Info className="w-4 h-4 text-amber-500" />
                    <span>1. About</span>
                  </button>

                  <button
                    onClick={() => {
                      if (cart.length > 0) {
                        setActiveTab('checkout');
                      } else {
                        setActiveTab('cart');
                      }
                      setMenuOpen(false);
                    }}
                    className="w-full flex items-center space-x-2.5 px-3 py-2.5 rounded-lg text-left text-xs font-semibold tracking-wider uppercase text-slate-300 hover:text-amber-400 hover:bg-slate-800/60 transition-colors"
                  >
                    <ShoppingBag className="w-4 h-4 text-amber-500" />
                    <span>2. Payment</span>
                  </button>

                  <button
                    onClick={() => {
                      resetFilters();
                      setShowHero(false);
                      setActiveTab('catalog');
                      setMenuOpen(false);
                    }}
                    className="w-full flex items-center space-x-2.5 px-3 py-2.5 rounded-lg text-left text-xs font-semibold tracking-wider uppercase text-slate-300 hover:text-amber-400 hover:bg-slate-800/60 transition-colors"
                  >
                    <Layers className="w-4 h-4 text-amber-500" />
                    <span>3. Collections</span>
                  </button>
                </div>
              </>
            )}
          </div>

          {/* Quick Stats on Mobile / Tab switcher */}
          <div className="flex md:hidden items-center space-x-1">
            <button
              onClick={() => setActiveTab('repairs')}
              className={`p-2.5 rounded-full transition-all border ${
                activeTab === 'repairs'
                  ? 'bg-amber-500 text-slate-950 border-amber-500'
                  : 'bg-slate-800/80 text-slate-200 border-slate-700/60'
              }`}
              title="Book Repair"
            >
              <Calendar className="w-5 h-5" />
            </button>
            {bookings.length > 0 && (
              <button
                onClick={() => setActiveTab('bookings-list')}
                className={`p-2.5 rounded-full transition-all border ${
                  activeTab === 'bookings-list'
                    ? 'bg-amber-500 text-slate-950 border-amber-500'
                    : 'bg-slate-800/80 text-slate-200 border-slate-700/60'
                }`}
                title="Bookings List"
              >
                <List className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
