/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useStore } from '../store';
import { ShoppingBag, Trash2, ArrowRight, ShieldCheck, Lock, ChevronRight } from 'lucide-react';

export default function Cart() {
  const { cart, updateQuantity, removeFromCart, clearCart, setActiveTab } = useStore();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const shippingCost = subtotal > 25000 ? 0 : 3800;
  const taxRate = 0.18; // 18% GST
  const taxAmount = subtotal * taxRate;
  const grandTotal = subtotal + shippingCost + taxAmount;

  if (cart.length === 0) {
    return (
      <div id="cart-empty-state" className="max-w-xl mx-auto px-4 py-16 text-center">
        <div className="w-20 h-20 bg-slate-900 border border-slate-800 rounded-full flex items-center justify-center mx-auto mb-6">
          <ShoppingBag className="w-8 h-8 text-slate-500 animate-[bounce_2s_infinite]" />
        </div>
        <h3 className="font-serif text-2xl text-slate-200 mb-2">Your collection vault is empty</h3>
        <p className="text-slate-400 text-sm max-w-sm mx-auto mb-8 leading-relaxed">
          You haven't selected any fine mechanical clocks yet. Explore our workshop catalog to select your perfect heirloom piece.
        </p>
        <button
          onClick={() => setActiveTab('catalog')}
          className="px-8 py-3 bg-amber-600 hover:bg-amber-500 text-slate-950 text-xs font-bold tracking-widest uppercase rounded-lg transition-all shadow-md"
        >
          Browse Our Timepieces
        </button>
      </div>
    );
  }

  return (
    <div id="cart-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex items-center space-x-2 text-xs font-semibold uppercase tracking-widest text-slate-500 mb-6">
        <span className="cursor-pointer hover:text-white" onClick={() => setActiveTab('catalog')}>Atelier</span>
        <ChevronRight className="w-3.5 h-3.5" />
        <span className="text-slate-300">Shopping Cart</span>
      </div>

      <h3 className="font-serif text-3xl tracking-wide text-white mb-8">
        Your Selection Vault
        <span className="font-sans text-xs font-normal text-slate-400 ml-3 uppercase tracking-wider block sm:inline">
          ({cart.length} distinct {cart.length === 1 ? 'item' : 'items'} selected)
        </span>
      </h3>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Cart Itemized List */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg p-6">
            <div className="flex justify-between items-center pb-4 border-b border-slate-800">
              <span className="text-xs font-bold uppercase tracking-widest text-slate-400">Selected Item</span>
              <button
                onClick={clearCart}
                className="text-xs text-red-400/80 hover:text-red-400 font-medium transition-colors flex items-center space-x-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear All</span>
              </button>
            </div>

            <div className="divide-y divide-slate-800">
              {cart.map((item) => (
                <div key={item.product.id} className="py-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  {/* Item Image & Description */}
                  <div className="flex items-center space-x-4">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-16 h-16 sm:w-20 sm:h-20 object-cover rounded-xl bg-slate-950 border border-slate-800/80 shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <span className="text-xxs font-semibold uppercase tracking-widest text-amber-500">
                        {item.product.category}
                      </span>
                      <h4 className="font-serif text-base text-white font-medium hover:text-amber-400 transition-colors cursor-pointer" onClick={() => setActiveTab('catalog')}>
                        {item.product.name}
                      </h4>
                      <p className="text-xs text-slate-500 mt-1">Origin: {item.product.specs.origin}</p>
                      
                      {/* Mobile specific spacing/pricing */}
                      <span className="text-xs text-amber-500 font-bold block sm:hidden mt-1">
                        {formatCurrency(item.product.price)} each
                      </span>
                    </div>
                  </div>

                  {/* Quantity and Actions */}
                  <div className="flex items-center justify-between sm:justify-end w-full sm:w-auto gap-6 sm:gap-8 border-t sm:border-t-0 border-slate-800/60 pt-3 sm:pt-0">
                    <div className="hidden sm:block text-right">
                      <span className="text-xs text-slate-500 block">Unit Price</span>
                      <span className="text-sm font-semibold text-slate-200">{formatCurrency(item.product.price)}</span>
                    </div>

                    {/* Quantity Adjustment */}
                    <div>
                      <span className="text-xxs text-slate-500 block sm:hidden mb-1">Quantity</span>
                      <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-1">
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                          disabled={item.quantity <= 1}
                          className="px-2 py-0.5 text-slate-400 hover:text-white disabled:opacity-30 disabled:hover:text-slate-400 text-xs font-bold"
                        >
                          -
                        </button>
                        <span className="px-3 text-xs text-slate-200 font-bold min-w-4 text-center">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                          disabled={item.quantity >= item.product.stock}
                          className="px-2 py-0.5 text-slate-400 hover:text-white disabled:opacity-30 disabled:hover:text-slate-400 text-xs font-bold"
                        >
                          +
                        </button>
                      </div>
                      {item.quantity === item.product.stock && (
                        <span className="text-[10px] text-amber-500 font-medium block text-center mt-1">Max stock reached</span>
                      )}
                    </div>

                    {/* Total column */}
                    <div className="text-right">
                      <span className="text-xxs text-slate-500 block sm:hidden">Subtotal</span>
                      <span className="text-sm font-bold text-amber-500 block">
                        {formatCurrency(item.product.price * item.quantity)}
                      </span>
                    </div>

                    {/* Delete item button */}
                    <button
                      onClick={() => removeFromCart(item.product.id)}
                      className="p-2 bg-slate-950 hover:bg-red-950/20 border border-slate-800 hover:border-red-900/40 rounded-lg text-slate-500 hover:text-red-400 transition-colors self-end sm:self-center"
                      title="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Secure details reminder */}
          <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 flex items-start space-x-3 text-xs text-slate-400 leading-relaxed">
            <ShieldCheck className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
            <div>
              <span className="text-slate-200 font-bold">Collector Guarantee:</span> High-end clocks are subject to strict timing calibrations. In addition to a double inspection at dispatch, your purchase includes a full 5-year mechanical movement warranty and secure, temperature-controlled transit insurance.
            </div>
          </div>
        </div>

        {/* Pricing Breakdown & Checkout Action */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg">
          <h4 className="font-serif text-lg text-white mb-4 border-b border-slate-800 pb-3">Valuation Summary</h4>
          
          <div className="space-y-3.5 text-xs text-slate-300 mb-6">
            <div className="flex justify-between">
              <span className="text-slate-500">Subtotal</span>
              <span className="font-semibold text-slate-200">{formatCurrency(subtotal)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500">Insured Delivery</span>
              {shippingCost === 0 ? (
                <span className="text-emerald-500 font-bold px-2 py-0.5 bg-emerald-950/40 border border-emerald-800/30 rounded-full uppercase tracking-wider text-[10px]">
                  Complimentary
                </span>
              ) : (
                <span className="font-semibold text-slate-200">{formatCurrency(shippingCost)}</span>
              )}
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">GST (18%)</span>
              <span className="font-semibold text-slate-200">{formatCurrency(taxAmount)}</span>
            </div>
            
            <div className="border-t border-slate-800 pt-4 mt-2 flex justify-between items-baseline">
              <span className="font-semibold text-white text-sm">Estimated Total</span>
              <span className="font-serif text-xl font-bold text-amber-500">{formatCurrency(grandTotal)}</span>
            </div>
          </div>

          <button
            id="proceed-checkout-btn"
            onClick={() => setActiveTab('checkout')}
            className="w-full py-4 bg-gradient-to-r from-amber-600 to-yellow-700 hover:from-amber-500 hover:to-yellow-600 text-slate-950 text-xs font-bold tracking-widest uppercase rounded-lg shadow-md hover:shadow-lg transition-all flex items-center justify-center space-x-2"
          >
            <span>Proceed to Secure Checkout</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <div className="flex items-center justify-center space-x-2 mt-4 text-[10px] text-slate-500">
            <Lock className="w-3.5 h-3.5" />
            <span>256-Bit SSL Encrypted Processing</span>
          </div>
        </div>
      </div>
    </div>
  );
}
