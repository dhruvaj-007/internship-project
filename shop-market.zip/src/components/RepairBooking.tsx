/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useStore } from '../store';
import { ClockCategory, ServiceType } from '../types';
import { Calendar, Hammer, HelpCircle, Wrench, ChevronRight, User, Mail, Phone, Info } from 'lucide-react';

export default function RepairBooking() {
  const { addBooking, setActiveTab } = useStore();

  const [formData, setFormData] = useState({
    clientName: '',
    clientEmail: '',
    clientPhone: '',
    clockCategory: 'Mantel' as ClockCategory,
    serviceType: 'tuning' as ServiceType,
    issueDescription: '',
    bookingDate: '',
    bookingTime: '10:00 AM',
  });

  const [errors, setErrors] = useState<any>({});

  const clockCategories: ClockCategory[] = ['Grandfather', 'Mantel', 'Wall', 'Cuckoo', 'Table'];

  const services = [
    {
      id: 'cleaning' as ServiceType,
      name: 'Ultrasonic De-grease & Cleaning',
      priceRange: '₹10,200 - ₹18,700',
      duration: '3-5 business days',
      description: 'Complete movement dismantlement, ultrasonic bath, pivot inspection, and fresh synthetic micro-oils application.',
    },
    {
      id: 'tuning' as ServiceType,
      name: 'Regulation & Beat Tuning',
      priceRange: '₹6,800 - ₹12,750',
      duration: '1-2 business days',
      description: 'Pendulum oscillation length adjustment, escapement correction, deadbeat synchrony, and calendar/chime alignment.',
    },
    {
      id: 'movement-repair' as ServiceType,
      name: 'Mechanical Movement Repair',
      priceRange: '₹27,200 - ₹46,750',
      duration: '7-14 business days',
      description: 'Bushing replacement, gear tooth repair, spring barrel reconstruction, pivot polishing, and extensive load testing.',
    },
    {
      id: 'restoration' as ServiceType,
      name: 'Complete Antique Restoration',
      priceRange: '₹55,250+',
      duration: '3-6 weeks',
      description: 'Full aesthetic wood/brass case refinishing, dialing silvering, dial painting repair, and historic gear blueprint matching.',
    },
  ];

  const timeSlots = [
    '09:00 AM', '10:00 AM', '11:00 AM', '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM'
  ];

  // Helper to ensure minimum date is tomorrow
  const getMinDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const validate = () => {
    const newErrors: any = {};
    if (!formData.clientName.trim()) newErrors.clientName = 'Full name is required';
    if (!formData.clientEmail.trim()) {
      newErrors.clientEmail = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.clientEmail)) {
      newErrors.clientEmail = 'Invalid email structure';
    }
    if (!formData.clientPhone.trim()) newErrors.clientPhone = 'Phone number is required';
    if (!formData.bookingDate) newErrors.bookingDate = 'Please select an appointment date';
    if (!formData.issueDescription.trim()) newErrors.issueDescription = 'Please explain the timing issue or symptoms';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    addBooking(formData);
  };

  const selectedServiceDetails = services.find(s => s.id === formData.serviceType);

  return (
    <div id="booking-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Breadcrumb */}
      <div className="flex items-center space-x-2 text-xs font-semibold uppercase tracking-widest text-slate-500 mb-6">
        <span className="cursor-pointer hover:text-white" onClick={() => setActiveTab('catalog')}>Atelier</span>
        <ChevronRight className="w-3.5 h-3.5" />
        <span className="text-slate-300">Horology Repair Booking</span>
      </div>

      <div className="text-center max-w-3xl mx-auto mb-12">
        <h3 className="font-serif text-3xl sm:text-4xl text-white font-medium mb-3">
          The Horological Repair & Restoration Workshop
        </h3>
        <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
          From historic wood-carved German cuckoos to majestic cathedral chime grandfather clocks, our expert horologists diagnose, restore, and calibrate your treasured clock with surgical precision.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Booking Form Card */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-lg">
          <h4 className="font-serif text-xl text-white mb-6 border-b border-slate-800 pb-3 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-amber-500" />
            <span>Appointment Details</span>
          </h4>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Owner Info Group */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-amber-500/80" />
                  <span>Full Name</span>
                </label>
                <input
                  type="text"
                  name="clientName"
                  value={formData.clientName}
                  onChange={handleInputChange}
                  placeholder="Arthur Pendelton"
                  className={`w-full px-4 py-2.5 bg-slate-950 border rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors ${
                    errors.clientName ? 'border-red-500/60 focus:border-red-500' : 'border-slate-800/80'
                  }`}
                />
                {errors.clientName && <span className="text-[10px] text-red-500 mt-1 block">{errors.clientName}</span>}
              </div>

              <div>
                <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-amber-500/80" />
                  <span>Email Address</span>
                </label>
                <input
                  type="email"
                  name="clientEmail"
                  value={formData.clientEmail}
                  onChange={handleInputChange}
                  placeholder="arthur@example.com"
                  className={`w-full px-4 py-2.5 bg-slate-950 border rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors ${
                    errors.clientEmail ? 'border-red-500/60 focus:border-red-500' : 'border-slate-800/80'
                  }`}
                />
                {errors.clientEmail && <span className="text-[10px] text-red-500 mt-1 block">{errors.clientEmail}</span>}
              </div>

              <div>
                <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-amber-500/80" />
                  <span>Phone Number</span>
                </label>
                <input
                  type="tel"
                  name="clientPhone"
                  value={formData.clientPhone}
                  onChange={handleInputChange}
                  placeholder="(555) 123-4567"
                  className={`w-full px-4 py-2.5 bg-slate-950 border rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors ${
                    errors.clientPhone ? 'border-red-500/60 focus:border-red-500' : 'border-slate-800/80'
                  }`}
                />
                {errors.clientPhone && <span className="text-[10px] text-red-500 mt-1 block">{errors.clientPhone}</span>}
              </div>
            </div>

            {/* Clock Category & Service Type Selectors */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Clock Category</label>
                <select
                  name="clockCategory"
                  value={formData.clockCategory}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800/80 rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors cursor-pointer"
                >
                  {clockCategories.map((cat) => (
                    <option key={cat} value={cat}>{cat} Clock</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Service Requested</label>
                <select
                  name="serviceType"
                  value={formData.serviceType}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800/80 rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors cursor-pointer"
                >
                  <option value="cleaning">Ultrasonic Deep Cleaning</option>
                  <option value="tuning">Beat Regulation & Tuning</option>
                  <option value="movement-repair">Mechanical Movement Repair</option>
                  <option value="restoration">Full Antique Restoration</option>
                </select>
              </div>
            </div>

            {/* Date & Time Scheduler Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Preferred Date</label>
                <input
                  type="date"
                  name="bookingDate"
                  min={getMinDate()}
                  value={formData.bookingDate}
                  onChange={handleInputChange}
                  className={`w-full px-4 py-2.5 bg-slate-950 border rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors cursor-pointer ${
                    errors.bookingDate ? 'border-red-500/60 focus:border-red-500' : 'border-slate-800/80'
                  }`}
                />
                {errors.bookingDate && <span className="text-[10px] text-red-500 mt-1 block">{errors.bookingDate}</span>}
              </div>

              <div>
                <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Preferred Time Slot</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {timeSlots.map((time) => (
                    <button
                      type="button"
                      key={time}
                      onClick={() => setFormData({ ...formData, bookingTime: time })}
                      className={`py-2 text-[11px] font-semibold rounded-lg border text-center transition-all ${
                        formData.bookingTime === time
                          ? 'bg-amber-600/15 border-amber-500/60 text-amber-400'
                          : 'bg-slate-950 border-slate-800/60 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                      }`}
                    >
                      {time.split(' ')[0]} <span className="text-[9px] font-normal">{time.split(' ')[1]}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Symptom Description text area */}
            <div>
              <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Clock Symptoms & Timing Issues</label>
              <textarea
                name="issueDescription"
                rows={4}
                value={formData.issueDescription}
                onChange={handleInputChange}
                placeholder="Example: The pendulum stops oscillating after 15 minutes. The Westminster chime triggers 5 minutes past the hour. Beautiful walnut casing is intact but springs have lost tension."
                className={`w-full px-4 py-3 bg-slate-950 border rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors resize-none placeholder:text-slate-600 leading-relaxed ${
                  errors.issueDescription ? 'border-red-500/60 focus:border-red-500' : 'border-slate-800/80'
                }`}
              />
              {errors.issueDescription && <span className="text-[10px] text-red-500 mt-1 block">{errors.issueDescription}</span>}
            </div>

            {/* Submit button */}
            <button
              id="confirm-booking-btn"
              type="submit"
              className="w-full py-4 bg-gradient-to-r from-amber-600 to-yellow-700 hover:from-amber-500 hover:to-yellow-600 text-slate-950 font-bold text-xs tracking-widest uppercase rounded-xl shadow-lg transition-all flex items-center justify-center space-x-2"
            >
              <Wrench className="w-4 h-4 text-slate-950" />
              <span>Confirm Diagnostic Booking</span>
            </button>
          </form>
        </div>

        {/* Dynamic Division Estimate Panel (Right) */}
        <div className="lg:col-span-4 space-y-6">
          {/* Diagnostic Price Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-md">
            <h4 className="font-serif text-lg text-white mb-4 border-b border-slate-800 pb-3 flex items-center gap-2">
              <Hammer className="w-4.5 h-4.5 text-amber-500" />
              <span>Service Division Quote</span>
            </h4>

            {selectedServiceDetails && (
              <div className="space-y-4">
                <div>
                  <span className="text-xxs font-bold uppercase tracking-widest text-amber-500">Service Category</span>
                  <h5 className="text-base text-slate-200 font-medium mt-1">{selectedServiceDetails.name}</h5>
                </div>

                <div className="grid grid-cols-2 gap-4 bg-slate-950 border border-slate-800/80 p-3 rounded-xl text-xs">
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block font-semibold mb-0.5">Price Range</span>
                    <span className="text-sm text-amber-500 font-bold">{selectedServiceDetails.priceRange}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block font-semibold mb-0.5">Est. Duration</span>
                    <span className="text-sm text-slate-200 font-medium">{selectedServiceDetails.duration}</span>
                  </div>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed">
                  {selectedServiceDetails.description}
                </p>
              </div>
            )}
          </div>

          {/* Logistics Inquiries / Instruction Box */}
          <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-6 space-y-4 text-xs text-slate-400 leading-relaxed">
            <div className="flex items-center space-x-2 text-slate-200 font-bold border-b border-slate-800/60 pb-2">
              <Info className="w-4.5 h-4.5 text-amber-500 shrink-0" />
              <span>Logistics & Transport Instructions</span>
            </div>

            {formData.clockCategory === 'Grandfather' ? (
              <p className="bg-amber-950/25 border border-amber-900/45 p-3 rounded-xl text-amber-400">
                <strong>In-Home Consultation:</strong> Due to the weight and complex suspension of Grandfather Clocks, we do not require you to transport it. A certified team will perform in-home diagnostics, dismantle support weights, and ship the movement component securely in an insulated travel trunk.
              </p>
            ) : (
              <p>
                <strong>Drop-off & Courier Shipping:</strong> For {formData.clockCategory} Clocks, you may bring the clock directly to our workshop on your scheduled date. If shipping, we will mail you a complimentary double-walled foam shell crate with return-insured shipping labels.
              </p>
            )}

            <ul className="space-y-1.5 list-disc pl-4 text-slate-500">
              <li>No initial charges are captured until diagnostic tear-down is complete.</li>
              <li>A full video report of your clock's gear-train under a microscope is provided.</li>
              <li>Includes fully comprehensive workshop liability bond.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
