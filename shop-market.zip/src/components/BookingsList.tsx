/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useStore } from '../store';
import { List, CalendarDays, Phone, Mail, Wrench, ShieldAlert, Trash2 } from 'lucide-react';

export default function BookingsList() {
  const { bookings, cancelBooking, setActiveTab } = useStore();

  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-emerald-950/80 text-emerald-400 border border-emerald-800/40';
      case 'in-progress':
        return 'bg-blue-950/80 text-blue-400 border border-blue-800/40';
      case 'confirmed':
        return 'bg-purple-950/80 text-purple-400 border border-purple-800/40';
      case 'pending':
      default:
        return 'bg-amber-950/80 text-amber-400 border border-amber-800/40';
    }
  };

  const getServiceLabel = (service: string) => {
    switch (service) {
      case 'cleaning':
        return 'Ultrasonic Deep Cleaning';
      case 'tuning':
        return 'Regulation & Beat Tuning';
      case 'movement-repair':
        return 'Mechanical Movement Repair';
      case 'restoration':
        return 'Complete Antique Restoration';
      default:
        return service;
    }
  };

  if (bookings.length === 0) {
    return (
      <div id="bookings-empty-state" className="max-w-xl mx-auto px-4 py-16 text-center">
        <div className="w-20 h-20 bg-slate-900 border border-slate-800 rounded-full flex items-center justify-center mx-auto mb-6">
          <List className="w-8 h-8 text-slate-500" />
        </div>
        <h3 className="font-serif text-2xl text-slate-200 mb-2">No Active Workshop Tickets</h3>
        <p className="text-slate-400 text-sm max-w-sm mx-auto mb-8 leading-relaxed">
          You don't have any clock repairs or aesthetic restoration appointments scheduled with our workshop.
        </p>
        <button
          onClick={() => setActiveTab('repairs')}
          className="px-8 py-3 bg-amber-600 hover:bg-amber-500 text-slate-950 text-xs font-bold tracking-widest uppercase rounded-lg transition-all shadow-md"
        >
          Book Clock Repair Service
        </button>
      </div>
    );
  }

  return (
    <div id="bookings-list-section" className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h3 className="font-serif text-3xl tracking-wide text-white mb-2">
        Active Workshop Diagnostics Tickets
      </h3>
      <p className="text-sm text-slate-400 mb-8 leading-relaxed">
        Verify the progression, scheduled timing, and logistics status of your mechanical timepieces. For live updates, call our watchmaker division with your ticket reference ID.
      </p>

      <div className="space-y-6">
        {bookings.map((booking) => (
          <div
            key={booking.id}
            id={`booking-card-${booking.id}`}
            className="bg-slate-900 border border-slate-800/90 rounded-2xl p-6 shadow-lg flex flex-col md:flex-row justify-between gap-6 hover:border-slate-700/60 transition-colors"
          >
            {/* Info details */}
            <div className="space-y-4 flex-1">
              {/* Ticket ID & Status Row */}
              <div className="flex flex-wrap items-center gap-3">
                <span className="font-mono text-xs font-bold text-amber-500 px-3 py-1 bg-slate-950 border border-slate-800/80 rounded-lg">
                  TICKET #{booking.id}
                </span>
                <span className={`text-xxs font-bold uppercase tracking-widest px-3 py-1 rounded-full ${getStatusStyle(booking.status)}`}>
                  {booking.status}
                </span>
              </div>

              {/* Clock & service title */}
              <div>
                <h4 className="font-serif text-lg text-white font-medium">
                  {booking.clockCategory} Clock • {getServiceLabel(booking.serviceType)}
                </h4>
                <p className="text-xs text-slate-400 mt-1 italic">
                  &ldquo;{booking.issueDescription}&rdquo;
                </p>
              </div>

              {/* Owner and Contact details block */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-slate-800/40 text-xs text-slate-400">
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-slate-500" />
                    <span>{booking.clientPhone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-slate-500" />
                    <span>{booking.clientEmail}</span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <CalendarDays className="w-3.5 h-3.5 text-slate-500" />
                    <span className="text-slate-300 font-medium">Scheduled: {booking.bookingDate}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Wrench className="w-3.5 h-3.5 text-slate-500" />
                    <span>Time block: {booking.bookingTime}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Cancel Actions */}
            <div className="flex md:flex-col justify-between items-end md:justify-center border-t md:border-t-0 md:border-l border-slate-800/60 pt-4 md:pt-0 md:pl-6 shrink-0 gap-4">
              <div className="text-left md:text-right hidden sm:block">
                <span className="text-xxs uppercase tracking-widest text-slate-500 block">Est. Cost Range</span>
                <span className="text-sm font-bold text-slate-300">
                  {booking.serviceType === 'cleaning' && '$120 - $220'}
                  {booking.serviceType === 'tuning' && '$80 - $150'}
                  {booking.serviceType === 'movement-repair' && '$320 - $550'}
                  {booking.serviceType === 'restoration' && '$650+'}
                </span>
              </div>

              <button
                id={`cancel-booking-${booking.id}`}
                onClick={() => {
                  if (confirm("Are you sure you want to retract this repair reservation? This action removes the active diagnostic ticket.")) {
                    cancelBooking(booking.id);
                  }
                }}
                className="px-4 py-2 bg-slate-950 hover:bg-red-950/25 border border-slate-800 hover:border-red-900/40 rounded-lg text-slate-400 hover:text-red-400 text-xs font-bold transition-all flex items-center justify-center space-x-1.5 self-end md:self-auto"
                title="Cancel ticket"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Cancel Ticket</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Workshop disclaimer */}
      <div className="mt-8 bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 flex items-start gap-3 text-xs text-slate-400 leading-relaxed">
        <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
        <div>
          <span className="text-slate-200 font-semibold">Specialist Note:</span> To dispatch complimentary packaging shells or arrange a heavy grandfather crane consultation, our team will call your provided phone number within 12 hours of diagnostic approval. Keep this screen or write down your ticket IDs for reference.
        </div>
      </div>
    </div>
  );
}
