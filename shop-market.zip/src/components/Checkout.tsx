/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useStore } from '../store';
import { Lock, CreditCard, ShieldCheck, ArrowLeft, Eye, EyeOff, Sparkles } from 'lucide-react';

export default function Checkout() {
  const { cart, completeCheckout, setActiveTab } = useStore();

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zip: '',
    cardName: '',
    cardNumber: '',
    cardExpiry: '',
    cardCvv: '',
  });

  const [errors, setErrors] = useState<any>({});
  const [showCvv, setShowCvv] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const shippingCost = subtotal > 25000 ? 0 : 3800;
  const taxRate = 0.18; // 18% GST
  const taxAmount = subtotal * taxRate;
  const grandTotal = subtotal + shippingCost + taxAmount;

  // Format Card Number (adds space every 4 digits)
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '').substring(0, 16);
    const formatted = value.match(/.{1,4}/g)?.join(' ') || value;
    setFormData({ ...formData, cardNumber: formatted });
  };

  // Format Expiration Date (adds / after 2 digits)
  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '').substring(0, 4);
    if (value.length > 2) {
      value = `${value.slice(0, 2)}/${value.slice(2)}`;
    }
    setFormData({ ...formData, cardExpiry: value });
  };

  const handleCvvChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '').substring(0, 3);
    setFormData({ ...formData, cardCvv: value });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const validateForm = () => {
    const newErrors: any = {};
    if (!formData.firstName.trim()) newErrors.firstName = 'Required';
    if (!formData.lastName.trim()) newErrors.lastName = 'Required';
    if (!formData.email.trim()) {
      newErrors.email = 'Required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Invalid email';
    }
    if (!formData.phone.trim()) newErrors.phone = 'Required';
    if (!formData.address.trim()) newErrors.address = 'Required';
    if (!formData.city.trim()) newErrors.city = 'Required';
    if (!formData.state.trim()) newErrors.state = 'Required';
    if (!formData.zip.trim()) {
      newErrors.zip = 'Required';
    } else if (formData.zip.replace(/\D/g, '').length < 5) {
      newErrors.zip = 'Invalid ZIP';
    }
    if (!formData.cardName.trim()) newErrors.cardName = 'Required';
    if (formData.cardNumber.replace(/\s/g, '').length < 16) {
      newErrors.cardNumber = 'Card number must be 16 digits';
    }
    if (!/^\d{2}\/\d{2}$/.test(formData.cardExpiry)) {
      newErrors.cardExpiry = 'Use MM/YY';
    } else {
      const [mm, yy] = formData.cardExpiry.split('/').map(Number);
      if (mm < 1 || mm > 12) {
        newErrors.cardExpiry = 'Invalid Month';
      }
    }
    if (formData.cardCvv.length < 3) {
      newErrors.cardCvv = 'Must be 3 digits';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);
    // Simulate real gateway latency
    setTimeout(() => {
      setIsSubmitting(false);
      completeCheckout(formData);
    }, 1800);
  };

  return (
    <div id="checkout-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Back navigation */}
      <button
        onClick={() => setActiveTab('cart')}
        className="flex items-center space-x-2 text-xs font-semibold text-slate-400 hover:text-white mb-8 transition-colors uppercase tracking-widest"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Return to Vault Selection</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Checkout Forms Column */}
        <div className="lg:col-span-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Shipping & Billing Address Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-md">
              <h4 className="font-serif text-lg text-white mb-6 flex items-center space-x-2 border-b border-slate-800 pb-3">
                <span className="w-6 h-6 bg-amber-500/15 border border-amber-500/30 text-amber-500 rounded-full flex items-center justify-center text-xs font-bold font-sans">1</span>
                <span>Insured Delivery Address</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5">First Name</label>
                  <input
                    type="text"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-2.5 bg-slate-950 border rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors ${
                      errors.firstName ? 'border-red-500/60 focus:border-red-500' : 'border-slate-800'
                    }`}
                  />
                  {errors.firstName && <span className="text-[10px] text-red-500 mt-1 block">{errors.firstName}</span>}
                </div>
                <div>
                  <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Last Name</label>
                  <input
                    type="text"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-2.5 bg-slate-950 border rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors ${
                      errors.lastName ? 'border-red-500/60 focus:border-red-500' : 'border-slate-800'
                    }`}
                  />
                  {errors.lastName && <span className="text-[10px] text-red-500 mt-1 block">{errors.lastName}</span>}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Email Address</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="you@example.com"
                    className={`w-full px-4 py-2.5 bg-slate-950 border rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors ${
                      errors.email ? 'border-red-500/60 focus:border-red-500' : 'border-slate-800'
                    }`}
                  />
                  {errors.email && <span className="text-[10px] text-red-500 mt-1 block">{errors.email}</span>}
                </div>
                <div>
                  <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Phone Number</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    placeholder="(555) 000-0000"
                    className={`w-full px-4 py-2.5 bg-slate-950 border rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors ${
                      errors.phone ? 'border-red-500/60 focus:border-red-500' : 'border-slate-800'
                    }`}
                  />
                  {errors.phone && <span className="text-[10px] text-red-500 mt-1 block">{errors.phone}</span>}
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Street Address</label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  placeholder="123 Chronos Way"
                  className={`w-full px-4 py-2.5 bg-slate-950 border rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors ${
                    errors.address ? 'border-red-500/60 focus:border-red-500' : 'border-slate-800'
                  }`}
                />
                {errors.address && <span className="text-[10px] text-red-500 mt-1 block">{errors.address}</span>}
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5">City</label>
                  <input
                    type="text"
                    name="city"
                    value={formData.city}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-2.5 bg-slate-950 border rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors ${
                      errors.city ? 'border-red-500/60 focus:border-red-500' : 'border-slate-800'
                    }`}
                  />
                  {errors.city && <span className="text-[10px] text-red-500 mt-1 block">{errors.city}</span>}
                </div>
                <div>
                  <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5">State</label>
                  <input
                    type="text"
                    name="state"
                    value={formData.state}
                    onChange={handleInputChange}
                    placeholder="CA"
                    className={`w-full px-4 py-2.5 bg-slate-950 border rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors ${
                      errors.state ? 'border-red-500/60 focus:border-red-500' : 'border-slate-800'
                    }`}
                  />
                  {errors.state && <span className="text-[10px] text-red-500 mt-1 block">{errors.state}</span>}
                </div>
                <div>
                  <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5">ZIP Code</label>
                  <input
                    type="text"
                    name="zip"
                    value={formData.zip}
                    onChange={handleInputChange}
                    placeholder="90210"
                    className={`w-full px-4 py-2.5 bg-slate-950 border rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors ${
                      errors.zip ? 'border-red-500/60 focus:border-red-500' : 'border-slate-800'
                    }`}
                  />
                  {errors.zip && <span className="text-[10px] text-red-500 mt-1 block">{errors.zip}</span>}
                </div>
              </div>
            </div>

            {/* Payment Details Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-md">
              <div className="flex justify-between items-center mb-6 border-b border-slate-800 pb-3">
                <h4 className="font-serif text-lg text-white flex items-center space-x-2">
                  <span className="w-6 h-6 bg-amber-500/15 border border-amber-500/30 text-amber-500 rounded-full flex items-center justify-center text-xs font-bold font-sans">2</span>
                  <span>Secure Payment Processing</span>
                </h4>
                <div className="flex items-center space-x-1.5 text-emerald-500 text-xs font-semibold uppercase tracking-wider">
                  <Lock className="w-3.5 h-3.5" />
                  <span>SSL Encrypted</span>
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Cardholder Name</label>
                <input
                  type="text"
                  name="cardName"
                  value={formData.cardName}
                  onChange={handleInputChange}
                  placeholder="As shown on credit card"
                  className={`w-full px-4 py-2.5 bg-slate-950 border rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors ${
                    errors.cardName ? 'border-red-500/60 focus:border-red-500' : 'border-slate-800'
                  }`}
                />
                {errors.cardName && <span className="text-[10px] text-red-500 mt-1 block">{errors.cardName}</span>}
              </div>

              {/* Card Number Input with Dynamic Card Icon */}
              <div className="mb-4 relative">
                <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Credit Card Number</label>
                <div className="relative">
                  <input
                    type="text"
                    value={formData.cardNumber}
                    onChange={handleCardNumberChange}
                    placeholder="0000 0000 0000 0000"
                    className={`w-full pl-11 pr-4 py-2.5 bg-slate-950 border rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors ${
                      errors.cardNumber ? 'border-red-500/60 focus:border-red-500' : 'border-slate-800'
                    }`}
                  />
                  <CreditCard className="w-5 h-5 text-slate-500 absolute left-3.5 top-3" />
                </div>
                {errors.cardNumber && <span className="text-[10px] text-red-500 mt-1 block">{errors.cardNumber}</span>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Expiration Date</label>
                  <input
                    type="text"
                    value={formData.cardExpiry}
                    onChange={handleExpiryChange}
                    placeholder="MM/YY"
                    className={`w-full px-4 py-2.5 bg-slate-950 border rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors ${
                      errors.cardExpiry ? 'border-red-500/60 focus:border-red-500' : 'border-slate-800'
                    }`}
                  />
                  {errors.cardExpiry && <span className="text-[10px] text-red-500 mt-1 block">{errors.cardExpiry}</span>}
                </div>
                <div>
                  <label className="block text-xxs font-bold uppercase tracking-wider text-slate-400 mb-1.5">CVV Code</label>
                  <div className="relative">
                    <input
                      type={showCvv ? 'text' : 'password'}
                      value={formData.cardCvv}
                      onChange={handleCvvChange}
                      placeholder="000"
                      className={`w-full pr-10 pl-4 py-2.5 bg-slate-950 border rounded-xl text-slate-200 text-sm focus:outline-none focus:border-amber-600 transition-colors ${
                        errors.cardCvv ? 'border-red-500/60 focus:border-red-500' : 'border-slate-800'
                      }`}
                    />
                    <button
                      type="button"
                      onClick={() => setShowCvv(!showCvv)}
                      className="absolute right-3 top-3 text-slate-500 hover:text-slate-300"
                    >
                      {showCvv ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {errors.cardCvv && <span className="text-[10px] text-red-500 mt-1 block">{errors.cardCvv}</span>}
                </div>
              </div>
            </div>

            {/* Submission Button */}
            <button
              id="submit-payment-btn"
              type="submit"
              disabled={isSubmitting}
              className={`w-full py-4.5 bg-gradient-to-r from-amber-600 to-yellow-700 hover:from-amber-500 hover:to-yellow-600 text-slate-950 font-bold text-xs tracking-widest uppercase rounded-xl shadow-lg transition-all flex items-center justify-center space-x-2.5 ${
                isSubmitting ? 'opacity-60 cursor-wait' : ''
              }`}
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                  <span>Authorizing Funds & Securing Assets...</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>Submit Authorized Payment — {formatCurrency(grandTotal)}</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Right Panel: Order Summary Breakdown */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg sticky top-24">
          <h4 className="font-serif text-lg text-white mb-4 border-b border-slate-800 pb-3">Vault Items Summary</h4>

          {/* List items mini scroll */}
          <div className="max-h-64 overflow-y-auto divide-y divide-slate-800/60 mb-6 pr-2">
            {cart.map((item) => (
              <div key={item.product.id} className="py-3 flex justify-between items-center text-xs gap-4">
                <div className="flex items-center space-x-3">
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-10 h-10 object-cover rounded-lg border border-slate-800"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h5 className="text-slate-200 font-medium line-clamp-1">{item.product.name}</h5>
                    <span className="text-slate-500 text-[10px] uppercase">Qty: {item.quantity}</span>
                  </div>
                </div>
                <span className="text-amber-500 font-semibold">{formatCurrency(item.product.price * item.quantity)}</span>
              </div>
            ))}
          </div>

          <div className="space-y-3.5 text-xs text-slate-400 mb-6 pt-4 border-t border-slate-800">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span className="text-slate-200 font-medium">{formatCurrency(subtotal)}</span>
            </div>
            <div className="flex justify-between">
              <span>Insured Delivery Courier</span>
              {shippingCost === 0 ? (
                <span className="text-emerald-500 font-semibold">Free</span>
              ) : (
                <span className="text-slate-200 font-medium">{formatCurrency(shippingCost)}</span>
              )}
            </div>
            <div className="flex justify-between">
              <span>GST (18%)</span>
              <span className="text-slate-200 font-medium">{formatCurrency(taxAmount)}</span>
            </div>

            <div className="border-t border-slate-800 pt-4 flex justify-between items-baseline">
              <span className="font-semibold text-white text-sm">Total Valuation</span>
              <span className="font-serif text-xl font-bold text-amber-500">{formatCurrency(grandTotal)}</span>
            </div>
          </div>

          {/* Secure lock notes */}
          <div className="p-4 bg-slate-950 border border-slate-800/80 rounded-xl space-y-3 text-[11px] text-slate-400 leading-relaxed">
            <div className="flex items-center space-x-2 text-slate-200 font-bold border-b border-slate-900 pb-1.5">
              <ShieldCheck className="w-4 h-4 text-amber-500" />
              <span>Full Insurance Bond</span>
            </div>
            <p>
              By proceeding, your payment is secured with a banking-level 256-Bit SSL protection gateway. We verify alignment of weights and perform double pendulum drop calibrations before shipping.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
