/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useStore } from '../store';
import { ClockProduct, ClockCategory } from '../types';
import { Search, SlidersHorizontal, ShoppingCart, Star, Eye, RotateCcw } from 'lucide-react';

export default function Catalog() {
  const { 
    products, 
    filters, 
    setFilters, 
    resetFilters, 
    addToCart, 
    setSelectedProduct 
  } = useStore();

  const categories: (ClockCategory | 'All')[] = ['All', 'Grandfather', 'Mantel', 'Wall', 'Cuckoo', 'Table'];

  // Apply filters
  const filteredProducts = products.filter((product) => {
    const matchesCategory = filters.category === 'All' || product.category === filters.category;
    const matchesPrice = product.price <= filters.maxPrice;
    const matchesSearch = product.name.toLowerCase().includes(filters.searchQuery.toLowerCase()) ||
                          product.description.toLowerCase().includes(filters.searchQuery.toLowerCase()) ||
                          product.specs.origin.toLowerCase().includes(filters.searchQuery.toLowerCase());
    return matchesCategory && matchesPrice && matchesSearch;
  });

  // Apply sorting
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (filters.sortBy) {
      case 'price-asc':
        return a.price - b.price;
      case 'price-desc':
        return b.price - a.price;
      case 'rating':
        return b.rating - a.rating;
      case 'featured':
      default:
        // Featured (stable sort by rating + price significance)
        return b.reviewCount * b.rating - a.reviewCount * a.rating;
    }
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div id="catalog-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Search & Filters Row */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 mb-8 shadow-lg">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          {/* Search bar */}
          <div className="relative md:col-span-5">
            <Search className="absolute left-3.5 top-3.5 h-4 w-4 text-slate-400" />
            <input
              id="search-input"
              type="text"
              placeholder="Search historical styles, materials, origin..."
              value={filters.searchQuery}
              onChange={(e) => setFilters({ searchQuery: e.target.value })}
              className="w-full pl-10 pr-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-600 transition-colors text-sm"
            />
          </div>

          {/* Sort selection */}
          <div className="relative md:col-span-3">
            <select
              id="sort-select"
              value={filters.sortBy}
              onChange={(e) => setFilters({ sortBy: e.target.value as any })}
              className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-amber-600 transition-colors text-sm appearance-none cursor-pointer"
            >
              <option value="featured">Sort: Featured</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Top Customer Rated</option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-slate-400">
              <SlidersHorizontal className="w-4 h-4 text-slate-500" />
            </div>
          </div>

          {/* Price Slider */}
          <div className="md:col-span-4 flex flex-col justify-center px-2">
            <div className="flex justify-between items-center text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              <span>Max Budget</span>
              <span className="text-amber-500 font-bold">{formatCurrency(filters.maxPrice)}</span>
            </div>
            <input
              id="price-range"
              type="range"
              min="10000"
              max="500000"
              step="5000"
              value={filters.maxPrice}
              onChange={(e) => setFilters({ maxPrice: Number(e.target.value) })}
              className="w-full accent-amber-500 h-1.5 bg-slate-950 rounded-lg cursor-pointer"
            />
          </div>
        </div>

        {/* Category Pill Buttons */}
        <div className="flex flex-wrap items-center gap-2 mt-6 pt-6 border-t border-slate-800/60">
          <span className="text-xs font-semibold uppercase tracking-widest text-slate-500 mr-2">Categories:</span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilters({ category: cat })}
              className={`px-4 py-1.5 rounded-full text-xs font-medium tracking-wide border transition-all duration-200 ${
                filters.category === cat
                  ? 'bg-amber-600/15 text-amber-400 border-amber-500/50 shadow-md shadow-amber-500/5'
                  : 'bg-slate-950 text-slate-400 border-slate-800/80 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
          
          {(filters.category !== 'All' || filters.searchQuery !== '' || filters.maxPrice !== 500000) && (
            <button
              onClick={resetFilters}
              className="ml-auto flex items-center space-x-1.5 text-xs text-amber-500/70 hover:text-amber-400 font-medium transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Filters</span>
            </button>
          )}
        </div>
      </div>

      {/* Catalog Grid Header */}
      <div className="flex justify-between items-center mb-6">
        <h3 className="font-serif text-2xl tracking-wide text-white">
          {filters.category === 'All' ? 'Our Complete Collection' : `${filters.category} Clocks`}
          <span className="font-sans text-xs font-normal text-slate-400 ml-3 uppercase tracking-wider">
            ({sortedProducts.length} {sortedProducts.length === 1 ? 'masterpiece' : 'masterpieces'})
          </span>
        </h3>
      </div>

      {/* Products Grid */}
      {sortedProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {sortedProducts.map((clock) => {
            const lowStock = clock.stock <= 3;
            
            return (
              <div
                key={clock.id}
                id={`product-card-${clock.id}`}
                className="group flex flex-col bg-slate-900 border border-slate-800/80 rounded-2xl overflow-hidden shadow-md hover:shadow-xl hover:border-slate-700/60 transition-all duration-350"
              >
                {/* Image Container with Hover zoom */}
                <div className="relative h-64 w-full bg-slate-950 overflow-hidden">
                  <img
                    src={clock.image}
                    alt={clock.name}
                    className="w-full h-full object-cover group-hover:scale-105 transform transition-transform duration-500 select-none"
                    referrerPolicy="no-referrer"
                  />
                  {/* Category overlay label */}
                  <span className="absolute top-4 left-4 px-3 py-1 bg-slate-950/80 backdrop-blur-sm border border-slate-800 rounded-full text-xxs font-bold text-amber-500 uppercase tracking-widest">
                    {clock.category}
                  </span>

                  {/* Stock status tag */}
                  <span className={`absolute top-4 right-4 px-2.5 py-1 rounded-full text-xxs font-bold uppercase tracking-wider ${
                    clock.stock === 0
                      ? 'bg-red-950/80 text-red-400 border border-red-800/40'
                      : lowStock
                      ? 'bg-amber-950/80 text-amber-400 border border-amber-800/40'
                      : 'bg-emerald-950/80 text-emerald-400 border border-emerald-800/40'
                  }`}>
                    {clock.stock === 0 ? 'Out of Stock' : lowStock ? `Only ${clock.stock} Left` : 'In Stock'}
                  </span>
                </div>

                {/* Info Container */}
                <div className="p-6 flex-1 flex flex-col">
                  <div className="flex justify-between items-start gap-2 mb-3">
                    <h4 className="font-serif text-lg text-white font-medium group-hover:text-amber-400 transition-colors line-clamp-1">
                      {clock.name}
                    </h4>
                    <span className="font-sans font-bold text-lg text-amber-500 shrink-0">
                      {formatCurrency(clock.price)}
                    </span>
                  </div>

                  <p className="text-sm text-slate-400 leading-relaxed line-clamp-2 mb-4 flex-1">
                    {clock.description}
                  </p>

                  {/* Rating / Metadata row */}
                  <div className="flex items-center space-x-2 mb-6 text-xs text-slate-400 border-t border-slate-800/60 pt-4">
                    <div className="flex items-center text-amber-400">
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <span className="font-semibold ml-1">{clock.rating}</span>
                    </div>
                    <span>•</span>
                    <span>{clock.reviewCount} master reviews</span>
                    <span>•</span>
                    <span className="italic">{clock.specs.origin}</span>
                  </div>

                  {/* Buttons */}
                  <div className="grid grid-cols-2 gap-3 mt-auto">
                    <button
                      id={`view-details-${clock.id}`}
                      onClick={() => setSelectedProduct(clock)}
                      className="px-4 py-2.5 bg-slate-950 border border-slate-800 hover:border-slate-700 hover:text-white text-slate-300 text-xs font-semibold tracking-wider uppercase rounded-lg transition-all flex items-center justify-center space-x-1.5"
                    >
                      <Eye className="w-3.5 h-3.5 text-slate-500" />
                      <span>Specifications</span>
                    </button>

                    <button
                      id={`add-to-cart-${clock.id}`}
                      onClick={() => addToCart(clock, 1)}
                      disabled={clock.stock === 0}
                      className={`px-4 py-2.5 text-xs font-semibold tracking-wider uppercase rounded-lg transition-all flex items-center justify-center space-x-1.5 ${
                        clock.stock === 0
                          ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-transparent'
                          : 'bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold border border-transparent hover:shadow-lg hover:shadow-amber-500/10'
                      }`}
                    >
                      <ShoppingCart className="w-3.5 h-3.5" />
                      <span>Add to Cart</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-16 bg-slate-900 border border-slate-800 rounded-2xl shadow-inner max-w-xl mx-auto">
          <SlidersHorizontal className="w-12 h-12 text-slate-600 mx-auto mb-4" />
          <h4 className="font-serif text-lg text-slate-300 mb-2">No masterpieces found</h4>
          <p className="text-slate-500 text-sm max-w-md mx-auto mb-6">
            We couldn't find any historical timepieces matching your active filter configuration. Try expanding your budget range or clearing search queries.
          </p>
          <button
            onClick={resetFilters}
            className="px-6 py-2.5 bg-amber-600 hover:bg-amber-500 text-slate-950 text-xs font-bold tracking-wider uppercase rounded-lg transition-all shadow-md"
          >
            Clear Search & Filters
          </button>
        </div>
      )}
    </div>
  );
}
