/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useStore } from '../store';
import { Shield, Hammer, Award, Compass } from 'lucide-react';
import heroImage from '../assets/images/atelier_hero_banner_1783074118201.jpg';

export default function Hero() {
  const { setActiveTab, resetFilters, setShowHero } = useStore();

  return (
    <div id="hero-section" className="relative bg-slate-950 text-white overflow-hidden border-b border-amber-900/20">
      {/* Background image overlayed with deep rich dark gradients */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Shop Market Clockmaker Atelier"
          className="w-full h-full object-cover opacity-35 object-center scale-105 transform transition-transform duration-10000 hover:scale-100"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/80 to-slate-900/60" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 lg:py-28 flex flex-col justify-center min-h-[500px]">
        <div className="max-w-2xl lg:max-w-3xl">
          {/* Subtle Accent Tag */}
          <div className="inline-flex items-center space-x-2 px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
            <span className="text-xs font-semibold text-amber-400 uppercase tracking-widest">Est. 1892 • Master Horologists</span>
          </div>

          <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl tracking-tight text-white font-medium leading-none mb-6">
            Timepieces of <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-600 font-normal italic">Enduring Legacy</span>
          </h2>
          
          <p className="text-base sm:text-lg lg:text-xl text-slate-300 leading-relaxed max-w-2xl mb-8">
            At Shop Market, we curate the finest mechanical grandfather clocks, mantel clocks, and artisan wall carvings. Every piece is a testimony to mechanical perfection, backed by certified master-level repair services and legacy restoration.
          </p>

          {/* Call to Actions */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-4 mb-12">
            <button
              id="hero-explore-btn"
              onClick={() => {
                resetFilters();
                setShowHero(false);
                setActiveTab('catalog');
              }}
              className="px-8 py-4 bg-gradient-to-r from-amber-600 to-yellow-700 hover:from-amber-500 hover:to-yellow-600 text-slate-950 text-sm font-semibold tracking-wider uppercase rounded-lg shadow-xl shadow-amber-950/20 hover:shadow-amber-500/10 transition-all text-center flex items-center justify-center space-x-2"
            >
              <span>Explore Collection</span>
            </button>
            
            <button
              id="hero-book-btn"
              onClick={() => setActiveTab('repairs')}
              className="px-8 py-4 bg-slate-900/90 border border-amber-600/30 hover:border-amber-400 text-slate-200 hover:text-white text-sm font-semibold tracking-wider uppercase rounded-lg transition-all text-center flex items-center justify-center space-x-2"
            >
              <Hammer className="w-4 h-4 text-amber-500" />
              <span>Book Master Repair</span>
            </button>
          </div>
        </div>

        {/* Feature Highlights Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 pt-10 border-t border-slate-900/80">
          <div className="flex items-start space-x-3">
            <Shield className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" />
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-200">5-Year Warranty</h4>
              <p className="text-xs text-slate-400">On all certified clocks</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-3">
            <Hammer className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" />
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-200">Expert Repairs</h4>
              <p className="text-xs text-slate-400">German-trained specialists</p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <Award className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" />
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-200">Fully Certified</h4>
              <p className="text-xs text-slate-400">Original mechanisms only</p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <Compass className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" />
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-200">Secure Insured Delivery</h4>
              <p className="text-xs text-slate-400">White-glove nationwide service</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
