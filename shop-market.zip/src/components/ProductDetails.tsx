/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useStore } from '../store';
import { X, Star, ShoppingCart, ShieldCheck, Truck, PackageCheck } from 'lucide-react';

export default function ProductDetails() {
  const { selectedProduct, setSelectedProduct, addToCart } = useStore();
  const [quantity, setQuantity] = useState(1);

  if (!selectedProduct) return null;

  const handleAddToCart = () => {
    addToCart(selectedProduct, quantity);
    setSelectedProduct(null); // Close modal
    setQuantity(1); // Reset
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const isLowStock = selectedProduct.stock <= 3;

  return (
    <div 
      className="fixed inset-0 z-50 overflow-y-auto" 
      aria-labelledby="modal-title" 
      role="dialog" 
      aria-modal="true"
    >
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
        {/* Backdrop overlay */}
        <div 
          onClick={() => setSelectedProduct(null)}
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm transition-opacity" 
          aria-hidden="true" 
        />

        {/* Center alignment trick */}
        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

        {/* Modal body container */}
        <div 
          id="product-details-modal"
          className="inline-block align-bottom bg-slate-900 border border-slate-800 rounded-2xl text-left overflow-hidden shadow-2xl transform transition-all sm:my-8 sm:align-middle sm:max-w-4xl sm:w-full"
        >
          {/* Header Close button */}
          <div className="absolute top-4 right-4 z-10">
            <button
              onClick={() => setSelectedProduct(null)}
              className="p-2 bg-slate-950/80 hover:bg-slate-800 border border-slate-800 rounded-full text-slate-400 hover:text-white transition-colors"
              aria-label="Close details"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2">
            {/* Left Column: Media & Highlights */}
            <div className="bg-slate-950 p-6 md:p-8 flex flex-col justify-between">
              <div className="relative h-72 sm:h-96 md:h-[350px] w-full rounded-xl overflow-hidden bg-slate-900 mb-6">
                <img
                  src={selectedProduct.image}
                  alt={selectedProduct.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute bottom-4 left-4 px-3 py-1 bg-slate-950/90 border border-slate-800 rounded-full text-xxs font-bold text-amber-500 uppercase tracking-widest">
                  {selectedProduct.category} Collection
                </span>
              </div>

              {/* Rating review breakout */}
              <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wide">Atelier Rating</span>
                  <span className="text-xs text-amber-500 font-bold flex items-center">
                    <Star className="w-3.5 h-3.5 fill-current mr-1" />
                    {selectedProduct.rating} / 5.0
                  </span>
                </div>
                <div className="w-full bg-slate-950 rounded-full h-2 mb-3">
                  <div className="bg-amber-500 h-2 rounded-full" style={{ width: `${(selectedProduct.rating / 5) * 100}%` }} />
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Rated by {selectedProduct.reviewCount} master collectors and certified clocksmiths who praise its timing consistency and case finishing.
                </p>
              </div>
            </div>

            {/* Right Column: Spec sheet & purchasing controls */}
            <div className="p-6 md:p-8 flex flex-col justify-between border-t md:border-t-0 md:border-l border-slate-800">
              <div>
                <span className="text-xs font-bold text-amber-500 uppercase tracking-widest mb-1.5 block">
                  Original Master Timepiece
                </span>
                <h3 className="font-serif text-2xl sm:text-3xl text-white font-medium leading-tight mb-2">
                  {selectedProduct.name}
                </h3>
                
                <div className="flex items-baseline space-x-3 mb-6">
                  <span className="text-2xl font-bold text-amber-500">
                    {formatCurrency(selectedProduct.price)}
                  </span>
                  <span className="text-xs text-slate-400">Included fully insured white-glove transport</span>
                </div>

                <p className="text-sm text-slate-300 leading-relaxed mb-6">
                  {selectedProduct.description}
                </p>

                {/* Technical Specs Table */}
                <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-800 pb-2 mb-3">
                  Technical Specifications
                </h4>
                <div className="space-y-2 mb-6 text-xs text-slate-300">
                  <div className="flex justify-between py-1 border-b border-slate-800/40">
                    <span className="text-slate-500">Material Casing</span>
                    <span className="font-medium text-slate-200">{selectedProduct.specs.material}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-800/40">
                    <span className="text-slate-500">Dimensions</span>
                    <span className="font-medium text-slate-200">{selectedProduct.specs.dimensions}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-800/40">
                    <span className="text-slate-500">Movement Engine</span>
                    <span className="font-medium text-slate-200">{selectedProduct.specs.movement}</span>
                  </div>
                  {selectedProduct.specs.chime && (
                    <div className="flex justify-between py-1 border-b border-slate-800/40">
                      <span className="text-slate-500">Chime Sequence</span>
                      <span className="font-medium text-slate-200">{selectedProduct.specs.chime}</span>
                    </div>
                  )}
                  <div className="flex justify-between py-1 border-b border-slate-800/40">
                    <span className="text-slate-500">Origin Handcraft</span>
                    <span className="font-medium text-slate-200">{selectedProduct.specs.origin}</span>
                  </div>
                </div>

                {/* Bulleted Features */}
                <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400 border-b border-slate-800 pb-2 mb-3">
                  Features & Inclusions
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-400 mb-6 pl-4 list-disc marker:text-amber-500">
                  {selectedProduct.features.map((feat, i) => (
                    <li key={i}>{feat}</li>
                  ))}
                </ul>
              </div>

              {/* Purchase Box */}
              <div className="bg-slate-950 border border-slate-800/60 rounded-xl p-4 mt-auto">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <span className="text-xs font-semibold text-slate-400 block mb-1">Availability</span>
                    <span className={`text-xs font-bold uppercase tracking-wider ${
                      selectedProduct.stock === 0 
                        ? 'text-red-500' 
                        : isLowStock 
                        ? 'text-amber-500' 
                        : 'text-emerald-500'
                    }`}>
                      {selectedProduct.stock === 0 
                        ? 'Out of Stock' 
                        : isLowStock 
                        ? `Only ${selectedProduct.stock} left in vault` 
                        : 'In stock & tested'}
                    </span>
                  </div>
                  
                  {selectedProduct.stock > 0 && (
                    <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-1">
                      <button
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        disabled={quantity <= 1}
                        className="px-2.5 py-1 text-slate-400 hover:text-white disabled:opacity-30 disabled:hover:text-slate-400 text-xs font-bold"
                      >
                        -
                      </button>
                      <span className="px-3 text-sm text-slate-200 font-bold select-none">{quantity}</span>
                      <button
                        onClick={() => setQuantity(Math.min(selectedProduct.stock, quantity + 1))}
                        disabled={quantity >= selectedProduct.stock}
                        className="px-2.5 py-1 text-slate-400 hover:text-white disabled:opacity-30 disabled:hover:text-slate-400 text-xs font-bold"
                      >
                        +
                      </button>
                    </div>
                  )}
                </div>

                <button
                  onClick={handleAddToCart}
                  disabled={selectedProduct.stock === 0}
                  className={`w-full py-3.5 rounded-lg text-xs font-bold tracking-wider uppercase transition-all flex items-center justify-center space-x-2 ${
                    selectedProduct.stock === 0
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      : 'bg-amber-600 hover:bg-amber-500 text-slate-950 shadow-md hover:shadow-amber-500/10'
                  }`}
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>Add {quantity} to Cart — {formatCurrency(selectedProduct.price * quantity)}</span>
                </button>

                {/* Warranties */}
                <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-900 text-[10px] text-slate-400 text-center">
                  <span className="flex items-center justify-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
                    <span>5y Warranty</span>
                  </span>
                  <span className="flex items-center justify-center gap-1">
                    <Truck className="w-3.5 h-3.5 text-amber-500" />
                    <span>Insured Delivery</span>
                  </span>
                  <span className="flex items-center justify-center gap-1">
                    <PackageCheck className="w-3.5 h-3.5 text-amber-500" />
                    <span>Compliant Original</span>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
