/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useStore } from '../store';
import { CheckCircle, Truck, Package, Calendar, Phone, ArrowRight, ClipboardList } from 'lucide-react';

export function OrderSuccess() {
  const { lastOrderDetails, setActiveTab } = useStore();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  if (!lastOrderDetails) {
    return (
      <div className="text-center py-16">
        <p className="text-slate-400">No active order details found.</p>
        <button onClick={() => setActiveTab('catalog')} className="mt-4 px-6 py-2.5 bg-amber-600 text-slate-950 font-bold uppercase rounded-lg">
          Return to Catalog
        </button>
      </div>
    );
  }

  const { orderId, items, total, billingInfo } = lastOrderDetails;

  return (
    <div id="order-success-panel" className="max-w-3xl mx-auto px-4 py-12">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl text-center relative overflow-hidden">
        {/* Dynamic decorative light beam */}
        <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-emerald-500 via-amber-500 to-yellow-600" />

        <div className="w-16 h-16 bg-emerald-950/80 border border-emerald-500/40 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="w-8 h-8 text-emerald-400 animate-[pulse_2s_infinite]" />
        </div>

        <span className="text-xxs font-bold text-emerald-500 uppercase tracking-widest mb-1.5 block">
          Authorized & Secured
        </span>
        <h3 className="font-serif text-3xl text-white font-medium mb-3">
          Your Heirloom Is Secured
        </h3>
        <p className="text-slate-400 text-sm max-w-lg mx-auto mb-8">
          Thank you for your purchase. We are preparing your clocks for double pendulum drop-tests and timing calibrations. Your transaction has processed securely.
        </p>

        {/* Invoice Card */}
        <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-6 text-left mb-8 space-y-4">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center pb-4 border-b border-slate-800 gap-2">
            <div>
              <span className="text-[10px] text-slate-500 uppercase block font-semibold">Order Reference</span>
              <span className="font-mono text-sm text-amber-500 font-bold">{orderId}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase block font-semibold sm:text-right">Customer Details</span>
              <span className="text-xs text-slate-300 font-medium sm:text-right block">
                {billingInfo.firstName} {billingInfo.lastName}
              </span>
            </div>
          </div>

          {/* Itemized list inside Invoice */}
          <div className="space-y-3 pb-4 border-b border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Secured Assets</span>
            {items.map((item) => (
              <div key={item.product.id} className="flex justify-between items-center text-xs">
                <span className="text-slate-300 font-medium">
                  {item.product.name} <span className="text-slate-500 text-[10px]">x{item.quantity}</span>
                </span>
                <span className="font-mono text-slate-200">{formatCurrency(item.product.price * item.quantity)}</span>
              </div>
            ))}
          </div>

          <div className="flex justify-between items-baseline pt-2">
            <span className="text-xs text-slate-400 font-bold uppercase">Total Authorized Amount</span>
            <span className="font-serif text-lg font-bold text-amber-500">{formatCurrency(total)}</span>
          </div>
        </div>

        {/* Logistics Steps */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left text-xs mb-8">
          <div className="flex items-start space-x-3 bg-slate-950/40 border border-slate-800 p-4 rounded-xl">
            <Truck className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" />
            <div>
              <h5 className="font-semibold text-slate-200">Insured Double-Boxed Shipping</h5>
              <p className="text-slate-400 mt-1">
                Your clock will be suspended in specialized temperature-controlled crates to avoid structural vibration.
              </p>
            </div>
          </div>

          <div className="flex items-start space-x-3 bg-slate-950/40 border border-slate-800 p-4 rounded-xl">
            <Package className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" />
            <div>
              <h5 className="font-semibold text-slate-200">Calibrations Report</h5>
              <p className="text-slate-400 mt-1">
                Includes a signed horology certificate recording beat error rate, amplitude, and pendulum oscillation drift.
              </p>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row justify-center items-stretch sm:items-center gap-4">
          <button
            onClick={() => setActiveTab('catalog')}
            className="px-8 py-3.5 bg-amber-600 hover:bg-amber-500 text-slate-950 text-xs font-bold tracking-widest uppercase rounded-lg transition-all shadow-md text-center"
          >
            Continue Browsing Atelier
          </button>
        </div>
      </div>
    </div>
  );
}

export function BookingSuccess() {
  const { lastBookingDetails, setActiveTab } = useStore();

  if (!lastBookingDetails) {
    return (
      <div className="text-center py-16">
        <p className="text-slate-400">No active booking details found.</p>
        <button onClick={() => setActiveTab('repairs')} className="mt-4 px-6 py-2.5 bg-amber-600 text-slate-950 font-bold uppercase rounded-lg">
          Return to Repairs
        </button>
      </div>
    );
  }

  const { id, clientName, clockCategory, serviceType, bookingDate, bookingTime } = lastBookingDetails;

  const getServiceLabel = (service: string) => {
    switch (service) {
      case 'cleaning':
        return 'Ultrasonic Deep Cleaning';
      case 'tuning':
        return 'Regulation & Beat Tuning';
      case 'movement-repair':
        return 'Mechanical Movement Repair';
      case 'restoration':
        return 'Complete Antique Restoration';
      default:
        return service;
    }
  };

  return (
    <div id="booking-success-panel" className="max-w-3xl mx-auto px-4 py-12">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl text-center relative overflow-hidden">
        {/* Dynamic decorative light beam */}
        <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-600" />

        <div className="w-16 h-16 bg-amber-950/80 border border-amber-500/40 rounded-full flex items-center justify-center mx-auto mb-6">
          <ClipboardList className="w-8 h-8 text-amber-400 animate-[pulse_2s_infinite]" />
        </div>

        <span className="text-xxs font-bold text-amber-500 uppercase tracking-widest mb-1.5 block">
          Workshop Ticket Logged
        </span>
        <h3 className="font-serif text-3xl text-white font-medium mb-3">
          Diagnostics Appointment Logged
        </h3>
        <p className="text-slate-400 text-sm max-w-lg mx-auto mb-8">
          Your request has been filed in the workshop schedule. A dedicated certified clockmaker will review your symptoms profile before your appointment.
        </p>

        {/* Diagnostic Ticket Details Card */}
        <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-6 text-left mb-8 space-y-4">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center pb-4 border-b border-slate-800 gap-2">
            <div>
              <span className="text-[10px] text-slate-500 uppercase block font-semibold">Diagnostic Ticket</span>
              <span className="font-mono text-sm text-amber-500 font-bold">#{id}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase block font-semibold sm:text-right">Clock Owner</span>
              <span className="text-xs text-slate-300 font-medium sm:text-right block">{clientName}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-slate-300 pt-2">
            <div>
              <span className="text-[10px] text-slate-500 uppercase block font-semibold mb-1">Timepiece category</span>
              <span className="font-serif text-sm font-medium text-slate-200">{clockCategory} Clock</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase block font-semibold mb-1">Diagnostic division</span>
              <span className="font-serif text-sm font-medium text-slate-200">{getServiceLabel(serviceType)}</span>
            </div>
            <div className="pt-2">
              <span className="text-[10px] text-slate-500 uppercase block font-semibold mb-1">Scheduled Date</span>
              <span className="text-slate-200 font-semibold flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-amber-500" />
                {bookingDate}
              </span>
            </div>
            <div className="pt-2">
              <span className="text-[10px] text-slate-500 uppercase block font-semibold mb-1">Assigned Time Slot</span>
              <span className="text-slate-200 font-semibold">{bookingTime}</span>
            </div>
          </div>
        </div>

        {/* Logistics Reminder */}
        <div className="bg-slate-950/40 border border-slate-800 p-5 rounded-2xl text-left text-xs text-slate-400 space-y-3 mb-8">
          <h5 className="font-semibold text-slate-200 flex items-center gap-1.5 border-b border-slate-800 pb-2">
            <Phone className="w-4 h-4 text-amber-500" />
            <span>Next Logistics Steps</span>
          </h5>
          <ol className="list-decimal pl-4 space-y-2 text-slate-400">
            <li>
              <strong>Telephone Callout:</strong> A clocksmith will call you within 12 hours of diagnostic approval to align on the drop-off or arrange heavy grandfather crane pickup logs.
            </li>
            <li>
              <strong>Padded Transit:</strong> If shipping, we will mail you a highly protective, foam-lined travel shell crate with prepaid return shipping.
            </li>
          </ol>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row justify-center items-stretch sm:items-center gap-4">
          <button
            onClick={() => setActiveTab('bookings-list')}
            className="px-8 py-3.5 bg-amber-600 hover:bg-amber-500 text-slate-950 text-xs font-bold tracking-widest uppercase rounded-lg transition-all shadow-md text-center flex items-center justify-center gap-2"
          >
            <span>View Appointment Tracker</span>
            <ArrowRight className="w-4 h-4 text-slate-950" />
          </button>
          
          <button
            onClick={() => setActiveTab('catalog')}
            className="px-6 py-3.5 bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white text-xs font-bold tracking-widest uppercase rounded-lg transition-all text-center"
          >
            Explore Clock Shop
          </button>
        </div>
      </div>
    </div>
  );
}
