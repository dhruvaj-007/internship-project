/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ClockCategory = 'Grandfather' | 'Mantel' | 'Wall' | 'Cuckoo' | 'Table';

export interface ClockProduct {
  id: string;
  name: string;
  category: ClockCategory;
  price: number;
  description: string;
  image: string;
  specs: {
    material: string;
    dimensions: string;
    movement: string;
    chime?: string;
    origin: string;
  };
  features: string[];
  rating: number;
  reviewCount: number;
  stock: number;
}

export interface CartItem {
  product: ClockProduct;
  quantity: number;
}

export type ServiceType = 'cleaning' | 'tuning' | 'movement-repair' | 'restoration';

export interface RepairBooking {
  id: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  clockCategory: ClockCategory;
  serviceType: ServiceType;
  issueDescription: string;
  bookingDate: string;
  bookingTime: string;
  status: 'pending' | 'confirmed' | 'in-progress' | 'completed';
  notes?: string;
}
