/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useStore } from './store';
import Header from './components/Header';
import Hero from './components/Hero';
import Catalog from './components/Catalog';
import ProductDetails from './components/ProductDetails';
import Cart from './components/Cart';
import Checkout from './components/Checkout';
import RepairBooking from './components/RepairBooking';
import BookingsList from './components/BookingsList';
import { OrderSuccess, BookingSuccess } from './components/SuccessScreens';
import { Clock, Phone, MapPin, Calendar, Award, Info, X } from 'lucide-react';

export default function App() {
  const { activeTab, isAboutOpen, setAboutOpen, showHero } = useStore();

  const renderActiveView = () => {
    switch (activeTab) {
      case 'catalog':
        return (
          <>
            {showHero && <Hero />}
            <Catalog />
          </>
        );
      case 'repairs':
        return <RepairBooking />;
      case 'cart':
        return <Cart />;
      case 'checkout':
        return <Checkout />;
      case 'bookings-list':
        return <BookingsList />;
      case 'order-success':
        return <OrderSuccess />;
      case 'booking-success':
        return <BookingSuccess />;
      default:
        return (
          <>
            {showHero && <Hero />}
            <Catalog />
          </>
        );
    }
  };

  return (
    <div className="bg-slate-950 text-slate-100 min-h-screen flex flex-col justify-between font-sans selection:bg-amber-600/30 selection:text-amber-300">
      {/* Stick Navigation Header */}
      <Header />

      {/* Main Dynamic Workspace content */}
      <main className="flex-grow">
        {renderActiveView()}
      </main>

      {/* Heritage Workshop Location Map Section */}
      <section className="bg-slate-900/40 border-t border-slate-800/60 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-5 space-y-4">
              <span className="text-[10px] font-bold text-amber-500 uppercase tracking-widest block">
                Heritage Workshop & Showroom
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl text-white font-medium">
                Visit Shop Market
              </h3>
              <p className="text-slate-400 text-sm leading-relaxed">
                Step into our sanctuary of classic horology. Meet our master clocksmiths, explore our selection vault, or bring your precious heirloom clocks for comprehensive diagnostics and calibration under a microscope.
              </p>
              <div className="space-y-2.5 text-xs text-slate-300">
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <span>
                    <strong>Shop Market Mumbai</strong><br />
                    The Heritage Chambers, Ground Floor, 34 Horniman Circle, Fort, Mumbai, Maharashtra 400001, India
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>Direct Clocksmith Line: +91 22 5550 0180</span>
                </div>
              </div>
            </div>
            <div className="lg:col-span-7 rounded-2xl overflow-hidden border border-slate-800 shadow-xl relative group h-80 bg-slate-950">
              <iframe
                id="shop-location-map"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3773.845722301826!2d72.8335!3d18.9325!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7d1c67d3e0983%3A0x6bfe86290887ee!2sHorniman%20Circle%2C%20Fort%2C%20Mumbai%2C%20Maharashtra%20400001!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
                className="w-full h-full opacity-85 group-hover:opacity-100 transition-opacity duration-300"
                style={{ border: 0 }}
                allowFullScreen={true}
                loading="lazy"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Shared Specifications Modal Overlay (active on catalog view) */}
      <ProductDetails />

      {/* Elegant Editorial Footer */}
      <footer className="bg-slate-900 border-t border-slate-800/80 pt-16 pb-8 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 mb-12">
            {/* Column 1: Brand & Bio */}
            <div className="md:col-span-4 space-y-4">
              <div className="flex items-center space-x-2">
                <Clock className="w-5 h-5 text-amber-500 animate-[spin_120s_linear_infinite]" />
                <h4 className="font-serif text-base tracking-widest font-semibold text-white">SHOP MARKET</h4>
              </div>
              <p className="text-slate-400 leading-relaxed pr-4">
                Preserving historical mechanics and aesthetic heritage since 1892. Our master horologists restore, regulate, and curate premium, authentic timepieces from Europe, the Americas, and Asia.
              </p>
              <div className="flex items-center gap-2 pt-2 text-[10px] text-amber-500 uppercase tracking-widest font-bold">
                <Award className="w-4 h-4 text-amber-500" />
                <span>Certified VDS Clock Association Partner</span>
              </div>
            </div>

            {/* Column 2: Hours & Location */}
            <div className="md:col-span-4 space-y-4">
              <h5 className="font-serif text-sm tracking-wider text-slate-200 font-medium uppercase">Atelier & Workshop</h5>
              <div className="space-y-3">
                <div className="flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <span>
                    The Heritage Chambers, Ground Floor<br />
                    34 Horniman Circle, Fort, Mumbai, 400001
                  </span>
                </div>
                <div className="flex items-start gap-2.5">
                  <Phone className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <span>Direct Clocksmith Line: +91 22 5550 0180</span>
                </div>
              </div>
            </div>

            {/* Column 3: Hours of Operation */}
            <div className="md:col-span-4 space-y-4">
              <h5 className="font-serif text-sm tracking-wider text-slate-200 font-medium uppercase">Calibrations Bureau Hours</h5>
              <div className="space-y-2">
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span>Monday — Thursday</span>
                  <span className="text-slate-300 font-medium">9:00 AM — 6:00 PM</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span>Friday (Testing Days)</span>
                  <span className="text-slate-300 font-medium">9:00 AM — 5:00 PM</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/40">
                  <span>Saturday (By Appt.)</span>
                  <span className="text-slate-300 font-medium">10:00 AM — 2:00 PM</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Sundays & Holidays</span>
                  <span>Closed (Vault Secured)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Row */}
          <div className="border-t border-slate-800/60 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-slate-500 text-[10px]">
            <p>&copy; {new Date().getFullYear()} Shop Market Clockmaker Atelier. All rights reserved. Registered LLC.</p>
            <div className="flex space-x-6">
              <span className="hover:text-amber-500 transition-colors cursor-pointer">Security Audits</span>
              <span>•</span>
              <span className="hover:text-amber-500 transition-colors cursor-pointer">Warranty Deeds</span>
              <span>•</span>
              <span className="hover:text-amber-500 transition-colors cursor-pointer">Pendulum Calibration Guides</span>
            </div>
          </div>
        </div>
      </footer>

      {/* About Modal Overlay */}
      {isAboutOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-8 relative shadow-2xl">
            <button
              onClick={() => setAboutOpen(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white hover:bg-slate-800/80 rounded-full transition-all"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="space-y-6">
              <div className="flex items-center space-x-2 text-amber-500">
                <Info className="w-5 h-5" />
                <span className="text-[10px] font-bold uppercase tracking-widest">ABOUT THE ATELIER</span>
              </div>
              
              <div className="space-y-4">
                <h3 className="font-serif text-2xl sm:text-3xl text-white font-medium">
                  SHOP MARKET
                </h3>
                <p className="text-slate-400 text-sm leading-relaxed">
                  Nestled in the historic Victorian architectural hub of Fort, Mumbai, Shop Market is India's premier destination for fine clocks. Since 1892, our master clocksmiths have preserved the ticking, mechanical heartbeats of exquisite grandfather, mantel, and antique wall clocks.
                </p>
                <p className="text-slate-400 text-sm leading-relaxed">
                  Every gear we recalibrate, every pendulum we sync, and every hand-rubbed timber frame we restore carries over a century of Swiss watchmaking lineage combined with classic Indian heritage.
                </p>
              </div>

              <div className="border-t border-slate-800/80 pt-6 space-y-3 text-xs text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-500">Founded</span>
                  <span className="font-semibold text-slate-200">1892</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Guild Certification</span>
                  <span className="font-semibold text-slate-200">VDS Clock Association</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Location</span>
                  <span className="font-semibold text-slate-200">Fort, Mumbai, MH, India</span>
                </div>
              </div>

              <button
                onClick={() => setAboutOpen(false)}
                className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-xs uppercase tracking-wider py-3.5 rounded-xl transition-all duration-200 active:scale-[0.98]"
              >
                Close Biography
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
