/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { CartItem, ClockProduct, ClockCategory, RepairBooking, ServiceType } from './types';
import { INITIAL_CLOCKS } from './data';

interface StoreState {
  // Products
  products: ClockProduct[];
  selectedProduct: ClockProduct | null;
  isAboutOpen: boolean;
  showHero: boolean;
  
  // UI Tabs & Navigation
  activeTab: 'catalog' | 'repairs' | 'cart' | 'checkout' | 'bookings-list' | 'order-success' | 'booking-success';
  lastOrderDetails: {
    orderId: string;
    items: CartItem[];
    total: number;
    billingInfo: any;
  } | null;
  lastBookingDetails: RepairBooking | null;

  // Shopping Cart
  cart: CartItem[];
  
  // Repair Bookings
  bookings: RepairBooking[];

  // Catalog Filters
  filters: {
    category: ClockCategory | 'All';
    maxPrice: number;
    searchQuery: string;
    sortBy: 'featured' | 'price-asc' | 'price-desc' | 'rating';
  };

  // Actions
  setSelectedProduct: (product: ClockProduct | null) => void;
  setAboutOpen: (open: boolean) => void;
  setShowHero: (show: boolean) => void;
  setActiveTab: (tab: StoreState['activeTab']) => void;
  
  // Cart Actions
  addToCart: (product: ClockProduct, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  
  // Booking Actions
  addBooking: (booking: Omit<RepairBooking, 'id' | 'status'>) => void;
  cancelBooking: (bookingId: string) => void;

  // Filter Actions
  setFilters: (filters: Partial<StoreState['filters']>) => void;
  resetFilters: () => void;
  
  // Checkout Action
  completeCheckout: (billingInfo: any) => void;
}

const defaultFilters = {
  category: 'All' as const,
  maxPrice: 500000,
  searchQuery: '',
  sortBy: 'featured' as const,
};

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      // Initial States
      products: INITIAL_CLOCKS,
      selectedProduct: null,
      isAboutOpen: false,
      showHero: true,
      activeTab: 'catalog',
      lastOrderDetails: null,
      lastBookingDetails: null,
      cart: [],
      bookings: [],
      filters: defaultFilters,

      // UI Actions
      setSelectedProduct: (product) => set({ selectedProduct: product }),
      setAboutOpen: (open) => set({ isAboutOpen: open }),
      setShowHero: (show) => set({ showHero: show }),
      setActiveTab: (tab) => set({ activeTab: tab }),

      // Cart Actions
      addToCart: (product, quantity = 1) => {
        const { cart } = get();
        const existingItemIndex = cart.findIndex((item) => item.product.id === product.id);

        if (existingItemIndex > -1) {
          const updatedCart = [...cart];
          const newQty = updatedCart[existingItemIndex].quantity + quantity;
          // Guard against stock limits
          updatedCart[existingItemIndex].quantity = Math.min(newQty, product.stock);
          set({ cart: updatedCart });
        } else {
          set({ cart: [...cart, { product, quantity: Math.min(quantity, product.stock) }] });
        }
      },

      removeFromCart: (productId) => {
        const { cart } = get();
        set({ cart: cart.filter((item) => item.product.id !== productId) });
      },

      updateQuantity: (productId, quantity) => {
        const { cart } = get();
        set({
          cart: cart.map((item) =>
            item.product.id === productId
              ? { ...item, quantity: Math.max(1, Math.min(quantity, item.product.stock)) }
              : item
          ),
        });
      },

      clearCart: () => set({ cart: [] }),

      // Booking Actions
      addBooking: (booking) => {
        const { bookings } = get();
        const newBooking: RepairBooking = {
          ...booking,
          id: `rep-${Math.floor(100000 + Math.random() * 900000)}`,
          status: 'pending',
        };
        set({
          bookings: [newBooking, ...bookings],
          lastBookingDetails: newBooking,
          activeTab: 'booking-success',
        });
      },

      cancelBooking: (bookingId) => {
        const { bookings } = get();
        set({
          bookings: bookings.map((b) =>
            b.id === bookingId ? { ...b, status: 'completed' as const } : b // Or we can delete it, or mark it canceled
          ).filter(b => b.id !== bookingId) // Let's just remove cancelled ones to keep list tidy, or keep with status
        });
      },

      // Filter Actions
      setFilters: (newFilters) => {
        set((state) => ({
          filters: { ...state.filters, ...newFilters },
        }));
      },

      resetFilters: () => set({ filters: defaultFilters }),

      // Checkout
      completeCheckout: (billingInfo) => {
        const { cart } = get();
        const total = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
        const orderId = `ORD-${Math.floor(100000 + Math.random() * 900000)}`;

        set({
          lastOrderDetails: {
            orderId,
            items: [...cart],
            total,
            billingInfo,
          },
          cart: [], // Clear cart
          activeTab: 'order-success',
        });
      },
    }),
    {
      name: 'chronos-clockmaker-storage',
      partialize: (state) => ({
        cart: state.cart,
        bookings: state.bookings,
      }), // only persist cart and bookings
    }
  )
);
